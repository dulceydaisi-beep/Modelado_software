import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;

public class ListarProveedores extends JFrame {
    private  JTable tablaProveedores;
    private DefaultTableModel modelo;

    public  ListarProveedores(){
        setTitle("Listado de Proveedores");
        setSize(700,400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        modelo = new DefaultTableModel(new String[]{"ID", "Nombre", "Telefono", "Email","Empresa"}, 0);
        tablaProveedores = new JTable(modelo);

        add(new JScrollPane(tablaProveedores), BorderLayout.CENTER);
        cargarProveedores();
    }
    private void cargarProveedores(){
        try (Connection conn = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/ims?useSSL= false&allowPublicKeyRetrieval=true&serverTimezone= UTC",
                "javauser", "12345")){
            String sql = "SELECT * FROM proveedores";
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            modelo.setRowCount(0);
            while (rs.next()){
                Object[] fila ={
                        rs.getInt("id"),
                        rs.getString("nombre"),
                        rs.getString("telefono"),
                        rs.getString("email"),
                        rs.getString("empresa")
            };
                modelo.addRow(fila);
        }
    }catch (SQLException ex){
            JOptionPane.showMessageDialog(this, "Error al cargar proveedores: " + ex.getMessage());
        }
}
public static void main(String[] args){
    SwingUtilities.invokeLater(()-> new  ListarProveedores().setVisible(true));
    }
}
