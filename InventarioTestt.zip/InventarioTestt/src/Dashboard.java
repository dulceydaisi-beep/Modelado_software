import javax.swing.*;
import java.awt.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class Dashboard extends JFrame {

    private String usuario;

    public Dashboard(String usuario) {
        this.usuario = usuario;

        setTitle("Dashboard - Usuario: " + usuario);
        setSize(750, 500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        // Fondo general pastel
        getContentPane().setBackground(new Color(245, 248, 255));

        // Panel central con grid para tarjetas
        JPanel panelTarjetas = new JPanel(new GridLayout(3, 2, 20, 20));
        panelTarjetas.setBackground(new Color(245, 248, 255));
        panelTarjetas.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // Tarjetas
        panelTarjetas.add(crearTarjeta("Productos", obtener("SELECT COUNT(*) FROM productos"),
                new Color(173, 216, 230), "🛒"));

        panelTarjetas.add(crearTarjeta("Clientes", obtener("SELECT COUNT(*) FROM clientes"),
                new Color(193, 225, 193), "👥"));

        panelTarjetas.add(crearTarjeta("Proveedores", obtener("SELECT COUNT(*) FROM proveedores"),
                new Color(255, 204, 204), "🚚"));

        panelTarjetas.add(crearTarjeta("Ventas", obtener("SELECT COUNT(*) FROM ventas"),
                new Color(255, 236, 179), "💰"));

        panelTarjetas.add(crearTarjeta("Stock total", obtener("SELECT SUM(cantidad) FROM productos"),
                new Color(221, 196, 255), "📦"));

        panelTarjetas.add(crearTarjeta("Total vendido", "$" + obtener("SELECT SUM(total) FROM ventas"),
                new Color(255, 215, 235), "📊"));

        add(panelTarjetas, BorderLayout.CENTER);

        // Botones inferiores
        JPanel panelBotones = new JPanel();
        panelBotones.setBackground(new Color(245, 248, 255));

        JButton btnMenu = new JButton("Menú Principal");
        JButton btnCerrar = new JButton("Cerrar");

        JButton btnGraficos = new JButton("Ver Gráficos");
        btnGraficos.setBackground(new Color(135,206,250));
        btnGraficos.setForeground(Color.DARK_GRAY);
        btnGraficos.setFocusPainted(false);
        btnGraficos.setFont(new Font("Segoe UI", Font.BOLD,14));
        btnGraficos.setBorder(BorderFactory.createEmptyBorder(10,20,10,20));

        estiloBotones(btnMenu, new Color(135, 206, 250));
        estiloBotones(btnCerrar, new Color(240, 128, 128));

        panelBotones.add(btnMenu);
        panelBotones.add(btnCerrar);
        panelBotones.add(btnGraficos);

        add(panelBotones, BorderLayout.SOUTH);

        // ACCIONES
        btnMenu.addActionListener(e -> {
            new MainMenu(usuario).setVisible(true);
            dispose();
        });

        btnCerrar.addActionListener(e -> dispose());

        btnGraficos.addActionListener(e-> new VentanaGraficos().setVisible(true));
    }

    // -------------------------
    // TARJETA ANIMADA
    // -------------------------
    private JPanel crearTarjeta(String titulo, Object valor, Color colorFondo, String icono) {

        JPanel tarjeta = new JPanel();
        tarjeta.setBackground(colorFondo);
        tarjeta.setLayout(new BorderLayout());
        tarjeta.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        tarjeta.setCursor(new Cursor(Cursor.HAND_CURSOR));

        // Sombra
        tarjeta.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(200, 200, 200), 1),
                BorderFactory.createEmptyBorder(10, 10, 10, 10)
        ));

        // Icono
        JLabel lblIcono = new JLabel(icono);
        lblIcono.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 40));
        lblIcono.setHorizontalAlignment(SwingConstants.CENTER);

        // Título
        JLabel lblTitulo = new JLabel(titulo);
        lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 18));
        lblTitulo.setHorizontalAlignment(SwingConstants.CENTER);

        // Valor
        JLabel lblValor = new JLabel(String.valueOf(valor));
        lblValor.setFont(new Font("Segoe UI", Font.BOLD, 22));
        lblValor.setHorizontalAlignment(SwingConstants.CENTER);

        tarjeta.add(lblIcono, BorderLayout.NORTH);
        tarjeta.add(lblTitulo, BorderLayout.CENTER);
        tarjeta.add(lblValor, BorderLayout.SOUTH);

        // ANIMACIÓN HOVER
        tarjeta.addMouseListener(new java.awt.event.MouseAdapter() {

            @Override
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                tarjeta.setBackground(colorFondo.brighter());
                tarjeta.setBorder(BorderFactory.createLineBorder(new Color(120, 120, 120), 2));
            }

            @Override
            public void mouseExited(java.awt.event.MouseEvent evt) {
                tarjeta.setBackground(colorFondo);
                tarjeta.setBorder(BorderFactory.createLineBorder(new Color(200, 200, 200), 1));
            }
        });

        return tarjeta;
    }

    // BOTONES
    private void estiloBotones(JButton boton, Color fondo) {
        boton.setBackground(fondo);
        boton.setForeground(Color.WHITE);
        boton.setFont(new Font("Segoe UI", Font.BOLD, 14));
        boton.setFocusPainted(false);
        boton.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        boton.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }

    // CONSULTAS
    private String obtener(String sql) {
        try (Connection conn = TestConnexion.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            if (rs.next()) {
                return rs.getString(1) != null ? rs.getString(1) : "0";
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "0";
    }

    // MAIN (para probar solo esta ventana)
    public static void main(String[] args) {
        new Dashboard("Admin").setVisible(true);
    }
}
