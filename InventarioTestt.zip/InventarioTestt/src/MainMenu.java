import javax.swing.*;
import java.awt.*;

public class MainMenu extends JFrame {

    public MainMenu(String usuario) {

        // CONFIGURACIÓN BÁSICA
        setTitle("Menú Principal - Usuario: " + usuario);
        setSize(700, 550);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // PANEL DE FONDO CON DEGRADADO
        JPanel panelFondo = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;

                GradientPaint gp = new GradientPaint(
                        0, 0, new Color(224, 247, 250),      // celeste pastel
                        0, getHeight(), new Color(200, 255, 229) // verde agua pastel
                );
                g2d.setPaint(gp);
                g2d.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        panelFondo.setLayout(new BorderLayout());
        add(panelFondo);

        // =============================================================
        // 🔵 BOTÓN DE CERRAR SESIÓN ARRIBA A LA DERECHA
        // =============================================================

        JPanel panelCerrarSesion = new JPanel(new BorderLayout());
        panelCerrarSesion.setOpaque(false);
        panelCerrarSesion.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JButton btnCerrarSesion = new JButton("Cerrar sesión");
        btnCerrarSesion.setBackground(new Color(220, 53, 69)); // rojo suave
        btnCerrarSesion.setForeground(Color.WHITE);
        btnCerrarSesion.setFocusPainted(false);
        btnCerrarSesion.setFont(new Font("Segoe UI", Font.BOLD, 14));

        panelCerrarSesion.add(btnCerrarSesion, BorderLayout.EAST);
        panelFondo.add(panelCerrarSesion, BorderLayout.NORTH);

        btnCerrarSesion.addActionListener(e -> {
            int confirm = JOptionPane.showConfirmDialog(
                    this,
                    "¿Desea cerrar sesión?",
                    "Confirmación",
                    JOptionPane.YES_NO_OPTION
            );
            if (confirm == JOptionPane.YES_OPTION) {
                dispose();
                new Login().setVisible(true);
            }
        });

        // =============================================================
        // 🔵 PANEL SUPERIOR (LOGO + TÍTULO)
        // =============================================================

        JPanel panelSuperior = new JPanel(new BorderLayout());
        panelSuperior.setOpaque(false);

        try {
            ImageIcon logo = new ImageIcon("src/imagenes/logo_tdb.png");
            JLabel lblLogo = new JLabel(new ImageIcon(logo.getImage().getScaledInstance(120, 120, Image.SCALE_SMOOTH)));
            lblLogo.setHorizontalAlignment(SwingConstants.CENTER);
            panelSuperior.add(lblLogo, BorderLayout.NORTH);
        } catch (Exception e) {
            System.out.println("No se encontró la imagen del logo.");
        }

        JLabel lblTitulo = new JLabel("SISTEMA DE INVENTARIO", SwingConstants.CENTER);
        lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 28));
        lblTitulo.setForeground(new Color(0, 102, 204));
        lblTitulo.setBorder(BorderFactory.createEmptyBorder(10, 10, 20, 10));

        panelSuperior.add(lblTitulo, BorderLayout.SOUTH);
        panelFondo.add(panelSuperior, BorderLayout.CENTER);

        // =============================================================
        // 🔵 PANEL DE BOTONES (CUADRICULA)
        // =============================================================

        JPanel panelBotones = new JPanel(new GridLayout(4, 2, 15, 15));
        panelBotones.setOpaque(false);
        panelBotones.setBorder(BorderFactory.createEmptyBorder(20, 80, 20, 80));

        JButton btnListar = new JButton("LISTAR PRODUCTOS");
        JButton btnAgregar = new JButton("AGREGAR PRODUCTOS");
        JButton btnExportar = new JButton("EXPORTAR A PDF");
        JButton btnClientes = new JButton("CLIENTES");
        JButton btnProveedores = new JButton("PROVEEDORES");
        JButton btnVentas = new JButton("VENTAS");
        JButton btnReporte = new JButton("REPORTE GENERAL");
        JButton btnDashboard = new JButton("DASHBOARD");

        JButton[] botones = {
                btnListar, btnAgregar, btnExportar, btnClientes,
                btnProveedores, btnVentas, btnReporte, btnDashboard
        };

        for (JButton b : botones) {
            b.setBackground(new Color(0, 102, 204));
            b.setForeground(Color.WHITE);
            b.setFont(new Font("Segoe UI", Font.BOLD, 15));
            b.setFocusPainted(false);
            b.setBorder(BorderFactory.createEmptyBorder(10, 15, 10, 15));
            panelBotones.add(b);
        }

        panelFondo.add(panelBotones, BorderLayout.SOUTH);

        // =============================================================
        // 🔵 ACCIONES DE LOS BOTONES
        // =============================================================

        btnListar.addActionListener(e -> new ListarProductos().setVisible(true));
        btnAgregar.addActionListener(e -> new AgregarProducto().setVisible(true));
        btnExportar.addActionListener(e -> JOptionPane.showMessageDialog(this, "Abrir ventana para exportar PDF"));
        btnClientes.addActionListener(e -> new ListarClientes().setVisible(true));
        btnProveedores.addActionListener(e -> new ListarProveedores().setVisible(true));
        btnVentas.addActionListener(e -> new ListarVentas().setVisible(true));
        btnReporte.addActionListener(e -> new ReporteGeneral(usuario).setVisible(true));
        btnDashboard.addActionListener(e -> new Dashboard(usuario).setVisible(true));
        btnVentas.addActionListener(e-> new ListarVentasReal().setVisible(true));
    }

    // MAIN PARA PRUEBAS
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new MainMenu("Admin").setVisible(true));
    }
}



//import javax.accessibility.AccessibleContext;
//import javax.swing.*;
//import java.awt.*;
//import java.awt.event.ActionEvent;

//public class MainMenu extends JFrame {

    //public MainMenu(String usuario) {

        //configuracion basica de la ventana
        //setTitle("Menu Principal - Usuario: " + usuario);
        //setSize(600, 500);
        //setLocationRelativeTo(null);
        //setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        //setLayout(new BorderLayout());

        //Panel con fondo degradado
        //JPanel panelFondo = new JPanel(){
            //@Override
            //public void paintComponent(Graphics g){
                //super.paintComponent(g);
                //Graphics2D g2d = (Graphics2D) g;
                //DEGRADADO VERTCAL
                //GradientPaint gradiente = new GradientPaint(0,0,
                    //    new Color(224,247,250),
                  //      0, getHeight(),
                //        new Color(200,255,229));
              //  g2d.setPaint(gradiente);
            //    g2d.fillRect(0,0,getWidth(), getHeight());
          //  }
        //};
        //panelFondo.setLayout(new BorderLayout());
        //add(panelFondo);

        //colores y fuentes
        //Color colorFondo = new Color(240, 248, 255);//AZUL PASTEL MUY SUAVE
        //Color colorBoton = new Color(100, 149, 237);//CELESTE MEDIO
        //Color colorTextoBoton = Color.WHITE;
        //Font fuenteBoton = new Font("Segoe UI", Font.BOLD, 15);
        //Font fuenteTitulo = new Font("Segoe UI", Font.BOLD, 22);

        //PANEL PRINCIPAL....BOTONES personalizados
        //JPanel panelSuperior = new JPanel(new BorderLayout());
        //panelSuperior.setOpaque(false);
        //add(panelPrincipal, BorderLayout.CENTER);


        //ETIQUETA DEL TITULO...TITULO CENTRADO
        //JLabel lblTitulo = new JLabel("SISTEMA DE INVENTARIO", SwingConstants.CENTER);
        //lblTitulo.setFont(fuenteTitulo);
        // lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 22));
        //lblTitulo.setForeground(new Color(0, 102, 204));
        //lblTitulo.setBorder(BorderFactory.createEmptyBorder(20, 10, 20, 10));
        //panelPrincipal.add(lblTitulo, BorderLayout.NORTH);

        //LOGO
        //try {
            //ImageIcon logo = new ImageIcon("src/imagenes/logo_tdb.png");
           // JLabel lblLogo = new JLabel(new ImageIcon(logo.getImage().getScaledInstance(100, 100, Image.SCALE_SMOOTH)));
           // lblLogo.setHorizontalAlignment(SwingConstants.CENTER);
          //  panelSuperior.add(lblLogo, BorderLayout.NORTH);
        //} catch (Exception e) {
         //   System.out.println("Logo no encontrado, continuando sin imagen....");
       // }
        //JLabel lblTitulo = new JLabel("SISTEMA DE INVENTARIO", SwingConstants.CENTER);
        //lblTitulo.setFont(new Font("Segoe UI", Font.BOLD,24));
        //lblTitulo.setForeground(new Color(0,102,204));
        //lblTitulo.setBorder(BorderFactory.createEmptyBorder(10,10,20,10));
        //panelSuperior.add(lblTitulo, BorderLayout.SOUTH);

        //panelFondo.add(panelSuperior, BorderLayout.NORTH);

        //panelFondo.add(lblTitulo, BorderLayout.NORTH);

        //PANEL BOTONES----crear botones
        //JPanel panelBotones = new JPanel(new GridLayout(4, 2, 15, 15));
        //panelBotones.setOpaque(false);
        //panelBotones.setBorder(BorderFactory.createEmptyBorder(20, 60, 20, 60));


        //JButton btnListar = new JButton("LISTAR PRODUCTOS");
        //JButton btnAgregar = new JButton("AGREGAR PRODUCTOS");
        //JButton btnExportar = new JButton("EXPORTAR PRODUCTOS A PDF");
        //JButton btnClientes = new JButton("CLIENTES");
        //JButton btnProveedores = new JButton("PROVEEDORES");
        //JButton btnVentas = new JButton("VENTAS");
        //JButton btnDashboard = new JButton("DASHBOARD");
        //JButton btnSalir = new JButton("CERRAR SESIÓN");
        //JButton btnReporte = new JButton("Reporte General");

        //JButton[] botones = {
          //      btnListar, btnAgregar, btnExportar, btnSalir, btnClientes, btnProveedores, btnVentas, btnReporte};

        //for (JButton b : botones) {
            //b.setBackground(new Color(0, 102, 204));
            //b.setForeground(Color.WHITE);
            //b.setFont(new Font("Segoe UI", Font.BOLD, 15));
            //b.setFocusPainted(false);
            //b.setBorder(BorderFactory.createEmptyBorder(10, 15, 10, 15));
            //b.setCursor(new Cursor(Cursor.HAND_CURSOR));
          //  panelBotones.add(b);
        //}
        //panelFondo.add(panelBotones, BorderLayout.CENTER);
        //panelBotones.add(btnDashboard);


        //ACCIONES DE BOTONES.....boton de clientes

        //btnListar.addActionListener((ActionEvent e) ->
          //      new ListarProductos().setVisible(true)
        //);
        //btnAgregar.addActionListener((ActionEvent e) ->
          //      new AgregarProducto().setVisible(true)
        //);
        //btnExportar.addActionListener((ActionEvent e) ->
          //      JOptionPane.showMessageDialog(this, "Abrir la ventana 'listar productos para exportar al PDF. ")
        //);
        //btnClientes.addActionListener(e ->
         //       new ListarClientes().setVisible(true)
        //);
        //btnProveedores.addActionListener(e ->
         //       new ListarProveedores().setVisible(true)
        //);
        //btnVentas.addActionListener((ActionEvent e) ->
          //      new ListarVentas().setVisible(true)
        //);
        //btnReporte.addActionListener(e ->{
          //  new ReporteGeneral().setVisible(true);
        //});
        //btnDashboard.addActionListener(e->{
          //  new Dashboard().setVisible(true);
        //});
        //btnSalir.addActionListener((ActionEvent e) -> {
          //  dispose();
        //    new Login().setVisible(true);
      //  });
    //}

    //public static void main(String[] args) {
    //    SwingUtilities.invokeLater(() -> new MainMenu("Admin").setVisible(true));
  //  }
//}



