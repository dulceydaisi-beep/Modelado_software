import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;
import java.text.DecimalFormat;

public class POSSupermercado extends JFrame {

    private JTextField txtBuscarCodigo;
    private JTextField txtCantidad;
    private JLabel lblNombreProducto;
    private JLabel lblPrecioProducto;
    private JLabel lblStockProducto;

    private JTable tablaCarrito;
    private DefaultTableModel modeloCarrito;

    private JLabel lblTotal;

    // Para guardar el producto encontrado (evita volver a parsear labels)
    private String productoCodigoActual = null;
    private String productoNombreActual = null;
    private double productoPrecioActual = 0;
    private int productoStockActual = 0;

    public POSSupermercado() {

        setTitle("Caja - Punto de Venta");
        setSize(900, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        // -------- PANEL SUPERIOR (BUSCADOR) --------
        JPanel panelSuperior = new JPanel(new GridLayout(2, 4, 10, 10));
        panelSuperior.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        panelSuperior.setBackground(new Color(224, 247, 250)); // pastel celeste

        panelSuperior.add(new JLabel("Código de barras:"));
        txtBuscarCodigo = new JTextField();
        panelSuperior.add(txtBuscarCodigo);

        JButton btnBuscar = new JButton("Buscar");
        panelSuperior.add(btnBuscar);

        JButton btnLimpiar = new JButton("Limpiar");
        panelSuperior.add(btnLimpiar);

        panelSuperior.add(new JLabel("Cantidad:"));
        txtCantidad = new JTextField("1");
        panelSuperior.add(txtCantidad);

        JButton btnAgregar = new JButton("Agregar al carrito");
        panelSuperior.add(btnAgregar);

        add(panelSuperior, BorderLayout.NORTH);

        // -------- PANEL INFORMACIÓN DEL PRODUCTO --------
        JPanel panelInfo = new JPanel(new GridLayout(1, 3));
        panelInfo.setBorder(BorderFactory.createTitledBorder("Datos del producto"));
        panelInfo.setBackground(new Color(255, 245, 238)); // pastel durazno

        lblNombreProducto = new JLabel("Nombre: -");
        lblPrecioProducto = new JLabel("Precio: -");
        lblStockProducto = new JLabel("Stock: -");

        panelInfo.add(lblNombreProducto);
        panelInfo.add(lblPrecioProducto);
        panelInfo.add(lblStockProducto);

        add(panelInfo, BorderLayout.WEST);

        // -------- TABLA CARRITO --------
        modeloCarrito = new DefaultTableModel(
                new String[]{"Código", "Producto", "Cant", "Precio", "Subtotal"}, 0
        ) {
            @Override
            public boolean isCellEditable(int row, int col) {
                return false; // no editable
            }
        };

        tablaCarrito = new JTable(modeloCarrito);
        tablaCarrito.setRowHeight(22);
        JScrollPane scroll = new JScrollPane(tablaCarrito);
        add(scroll, BorderLayout.CENTER);

        // -------- PANEL TOTAL Y FINALIZAR --------
        JPanel panelInferior = new JPanel(new GridLayout(1, 2));
        panelInferior.setBackground(new Color(200, 255, 229)); // pastel verde menta

        lblTotal = new JLabel("TOTAL: $0.00");
        lblTotal.setFont(new Font("Segoe UI", Font.BOLD, 20));
        panelInferior.add(lblTotal);

        JButton btnFinalizar = new JButton("Finalizar Venta");
        panelInferior.add(btnFinalizar);

        add(panelInferior, BorderLayout.SOUTH);

        // -------- EVENTOS --------
        btnBuscar.addActionListener(e -> buscarProducto());
        btnAgregar.addActionListener(e -> agregarAlCarrito());
        btnFinalizar.addActionListener(e -> registrarVenta());
        btnLimpiar.addActionListener(e -> limpiarTodo());

        // Buscar al presionar Enter en código de barras
        txtBuscarCodigo.addActionListener(e -> buscarProducto());
    }

    // ---------------- CONEXIÓN ----------------
    private Connection conexion() throws SQLException {
        return DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/ims?useSSL=false&serverTimezone=UTC",
                "javauser", "12345"
        );
    }

    // ---------------- BUSCAR PRODUCTO POR CÓDIGO ----------------
    private void buscarProducto() {
        String codigo = txtBuscarCodigo.getText().trim();

        if (codigo.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Ingrese un código de barras.");
            return;
        }

        String sql = "SELECT id, nombre, precio, cantidad FROM productos WHERE codigo_barra = ?";

        try (Connection conn = conexion();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, codigo);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                productoCodigoActual = codigo;
                productoNombreActual = rs.getString("nombre");
                productoPrecioActual = rs.getDouble("precio");
                productoStockActual = rs.getInt("cantidad");

                lblNombreProducto.setText("Nombre: " + productoNombreActual);
                lblPrecioProducto.setText("Precio: $" + productoPrecioActual);
                lblStockProducto.setText("Stock: " + productoStockActual);

            } else {
                JOptionPane.showMessageDialog(this, "No existe producto con ese código.");
                limpiarProductoActual();
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al buscar: " + e.getMessage());
            limpiarProductoActual();
        }
    }

    // ---------------- AGREGAR AL CARRITO ----------------
    private void agregarAlCarrito() {

        if (productoCodigoActual == null) {
            JOptionPane.showMessageDialog(this, "Busque un producto primero.");
            return;
        }

        int cant;
        try {
            cant = Integer.parseInt(txtCantidad.getText().trim());
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Cantidad inválida.");
            return;
        }

        if (cant <= 0) {
            JOptionPane.showMessageDialog(this, "La cantidad debe ser mayor a 0.");
            return;
        }

        if (cant > productoStockActual) {
            JOptionPane.showMessageDialog(this, "Stock insuficiente.");
            return;
        }

        double subtotal = productoPrecioActual * cant;

        // Si el producto ya está en carrito, sumamos cantidad
        for (int i = 0; i < modeloCarrito.getRowCount(); i++) {
            String codFila = modeloCarrito.getValueAt(i, 0).toString();
            if (codFila.equals(productoCodigoActual)) {
                int cantActual = Integer.parseInt(modeloCarrito.getValueAt(i, 2).toString());
                int nuevaCant = cantActual + cant;

                if (nuevaCant > productoStockActual) {
                    JOptionPane.showMessageDialog(this, "Stock insuficiente para sumar más.");
                    return;
                }

                modeloCarrito.setValueAt(nuevaCant, i, 2);
                modeloCarrito.setValueAt(productoPrecioActual * nuevaCant, i, 4);
                actualizarTotal();
                return;
            }
        }

        modeloCarrito.addRow(new Object[]{
                productoCodigoActual,
                productoNombreActual,
                cant,
                productoPrecioActual,
                subtotal
        });

        actualizarTotal();
    }

    // ---------------- ACTUALIZA TOTAL ----------------
    private void actualizarTotal() {
        double total = 0;

        for (int i = 0; i < modeloCarrito.getRowCount(); i++) {
            total += Double.parseDouble(modeloCarrito.getValueAt(i, 4).toString());
        }

        DecimalFormat df = new DecimalFormat("#0.00");
        lblTotal.setText("TOTAL: $" + df.format(total));
    }

    // ---------------- FINALIZAR VENTA ----------------
    private void registrarVenta() {

        if (modeloCarrito.getRowCount() == 0) {
            JOptionPane.showMessageDialog(this, "No hay productos en el carrito.");
            return;
        }

        double totalVenta = 0;
        for (int i = 0; i < modeloCarrito.getRowCount(); i++) {
            totalVenta += Double.parseDouble(modeloCarrito.getValueAt(i, 4).toString());
        }

        String sqlVenta = "INSERT INTO ventas (fecha, total) VALUES (NOW(), ?)";
        String sqlDetalle = "INSERT INTO detalle_ventas (venta_id, producto_id, cantidad, precio_unitario, subtotal) " +
                "VALUES (?, ?, ?, ?, ?)";
        String sqlStock = "UPDATE productos SET cantidad = cantidad - ? WHERE codigo_barra = ?";

        try (Connection conn = conexion()) {

            conn.setAutoCommit(false); // iniciar transacción

            // 1) Registrar venta
            int ventaId;
            try (PreparedStatement psVenta = conn.prepareStatement(sqlVenta, Statement.RETURN_GENERATED_KEYS)) {
                psVenta.setDouble(1, totalVenta);
                psVenta.executeUpdate();

                ResultSet rs = psVenta.getGeneratedKeys();
                if (!rs.next()) throw new SQLException("No se pudo generar ID de venta.");
                ventaId = rs.getInt(1);
            }

            // 2) Registrar detalle + descontar stock
            try (PreparedStatement psDetalle = conn.prepareStatement(sqlDetalle);
                 PreparedStatement psStock = conn.prepareStatement(sqlStock);
                 PreparedStatement psProd = conn.prepareStatement("SELECT id FROM productos WHERE codigo_barra = ?")) {

                for (int i = 0; i < modeloCarrito.getRowCount(); i++) {

                    String codigo = modeloCarrito.getValueAt(i, 0).toString();
                    int cant = Integer.parseInt(modeloCarrito.getValueAt(i, 2).toString());
                    double precio = Double.parseDouble(modeloCarrito.getValueAt(i, 3).toString());
                    double subtotal = Double.parseDouble(modeloCarrito.getValueAt(i, 4).toString());

                    // buscar id producto
                    psProd.setString(1, codigo);
                    ResultSet rsProd = psProd.executeQuery();
                    if (!rsProd.next()) throw new SQLException("Producto no existe: " + codigo);
                    int idProducto = rsProd.getInt("id");

                    // detalle venta
                    psDetalle.setInt(1, ventaId);
                    psDetalle.setInt(2, idProducto);
                    psDetalle.setInt(3, cant);
                    psDetalle.setDouble(4, precio);
                    psDetalle.setDouble(5, subtotal);
                    psDetalle.executeUpdate();

                    // descontar stock
                    psStock.setInt(1, cant);
                    psStock.setString(2, codigo);
                    psStock.executeUpdate();
                }
            }

            conn.commit();

            JOptionPane.showMessageDialog(this,
                    "✔ Venta registrada correctamente.\nN° Venta: " + totalVenta);

            // limpiar
            modeloCarrito.setRowCount(0);
            lblTotal.setText("TOTAL: $0.00");
            limpiarProductoActual();
            txtBuscarCodigo.setText("");
            txtCantidad.setText("1");

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error al registrar venta: " + e.getMessage());
            e.printStackTrace();
        }
    }

    // ---------------- LIMPIAR SOLO PRODUCTO ACTUAL ----------------
    private void limpiarProductoActual() {
        productoCodigoActual = null;
        productoNombreActual = null;
        productoPrecioActual = 0;
        productoStockActual = 0;

        lblNombreProducto.setText("Nombre: -");
        lblPrecioProducto.setText("Precio: -");
        lblStockProducto.setText("Stock: -");
    }

    // ---------------- LIMPIAR TODO (incluye carrito) ----------------
    private void limpiarTodo() {
        limpiarProductoActual();
        txtBuscarCodigo.setText("");
        txtCantidad.setText("1");
        modeloCarrito.setRowCount(0);
        lblTotal.setText("TOTAL: $0.00");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new POSSupermercado().setVisible(true));
    }
}