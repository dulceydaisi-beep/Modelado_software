import javax.swing.*;
import java.awt.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ReporteGeneral extends JFrame {

    private String usuario;

    // Labels que vamos a actualizar con los datos reales
    private JLabel lblProductos;
    private JLabel lblClientes;
    private JLabel lblProveedores;
    private JLabel lblVentas;
    private JLabel lblTotal;

    // Constructor sin parámetros (por si en algún lado usan new ReporteGeneral())
    public ReporteGeneral() {
        this("Admin");
    }

    // Constructor principal con usuario
    public ReporteGeneral(String usuario) {
        this.usuario = usuario;
        inicializarUI();
        cargarDatos();
    }

    // ================== INTERFAZ GRÁFICA ==================
    private void inicializarUI() {
        setTitle("Reporte General del Sistema - Usuario: " + usuario);
        setSize(600, 420);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        getContentPane().setBackground(new Color(240, 245, 255));
        setLayout(new BorderLayout());

        // Título superior
        JLabel titulo = new JLabel("REPORTE GENERAL DEL SISTEMA", SwingConstants.CENTER);
        titulo.setFont(new Font("Segoe UI", Font.BOLD, 22));
        titulo.setForeground(new Color(0, 102, 204));
        titulo.setBorder(BorderFactory.createEmptyBorder(15, 10, 15, 10));
        add(titulo, BorderLayout.NORTH);

        // Panel central con tarjetas
        JPanel panelCentral = new JPanel(new GridLayout(3, 2, 15, 15));
        panelCentral.setBorder(BorderFactory.createEmptyBorder(15, 20, 15, 20));
        panelCentral.setOpaque(false);

        // Colores pastel
        Color azul = new Color(200, 230, 255);
        Color verde = new Color(210, 245, 210);
        Color rosa = new Color(255, 220, 235);
        Color amarillo = new Color(255, 245, 210);
        Color violeta = new Color(230, 220, 255);

        lblProductos   = crearTarjeta("Productos: 0", azul);
        lblClientes    = crearTarjeta("Clientes: 0", verde);
        lblProveedores = crearTarjeta("Proveedores: 0", rosa);
        lblVentas      = crearTarjeta("Ventas: 0", amarillo);
        lblTotal       = crearTarjeta("Total vendido: $0,00", violeta);

        panelCentral.add(lblProductos);
        panelCentral.add(lblClientes);
        panelCentral.add(lblProveedores);
        panelCentral.add(lblVentas);
        panelCentral.add(lblTotal);

        add(panelCentral, BorderLayout.CENTER);

        // Panel de botones abajo
        JPanel panelBotones = new JPanel();
        panelBotones.setOpaque(false);

        JButton btnDashboard = new JButton("Dashboard");
        JButton btnCerrar = new JButton("Cerrar");

        estilizarBoton(btnDashboard, new Color(0, 122, 255));
        estilizarBoton(btnCerrar, new Color(230, 70, 70));

        btnDashboard.addActionListener(e -> {
            // Asumo que tu Dashboard tiene constructor sin parámetros
            new Dashboard(usuario).setVisible(true);
            dispose();
        });

        btnCerrar.addActionListener(e -> dispose());

        panelBotones.add(btnDashboard);
        panelBotones.add(btnCerrar);

        add(panelBotones, BorderLayout.SOUTH);
    }

    private JLabel crearTarjeta(String texto, Color fondo) {
        JLabel lbl = new JLabel(texto, SwingConstants.CENTER);
        lbl.setOpaque(true);
        lbl.setBackground(fondo);
        lbl.setFont(new Font("Segoe UI", Font.BOLD, 18));
        lbl.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(180, 180, 180)),
                BorderFactory.createEmptyBorder(10, 10, 10, 10)
        ));
        return lbl;
    }

    private void estilizarBoton(JButton boton, Color color) {
        boton.setBackground(color);
        boton.setForeground(Color.WHITE);
        boton.setFont(new Font("Segoe UI", Font.BOLD, 14));
        boton.setFocusPainted(false);
        boton.setBorder(BorderFactory.createEmptyBorder(8, 20, 8, 20));
        boton.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }

    // ================== CARGA DE DATOS ==================
    private void cargarDatos() {
        try (Connection conn = TestConnexion.getConnection()) {

            int productos   = contar(conn, "SELECT COUNT(*) FROM productos");
            int clientes    = contar(conn, "SELECT COUNT(*) FROM clientes");
            int proveedores = contar(conn, "SELECT COUNT(*) FROM proveedores");
            int ventas      = contar(conn, "SELECT COUNT(*) FROM ventas");
            double total    = sumarTotal(conn, "SELECT SUM(total) FROM ventas");

            lblProductos.setText("Productos: " + productos);
            lblClientes.setText("Clientes: " + clientes);
            lblProveedores.setText("Proveedores: " + proveedores);
            lblVentas.setText("Ventas: " + ventas);
            lblTotal.setText("Total vendido: $" + String.format("%,.2f", total));

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this,
                    "Error al cargar datos del reporte: " + e.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    private int contar(Connection conn, String sql) throws SQLException {
        try (PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            if (rs.next()) {
                return rs.getInt(1);
            }
        }
        return 0;
    }

    private double sumarTotal(Connection conn, String sql) throws SQLException {
        try (PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            if (rs.next()) {
                return rs.getDouble(1);
            }
        }
        return 0;
    }

    // Main SOLO para probar esta ventana aislada
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new ReporteGeneral("Admin").setVisible(true));
    }
}
