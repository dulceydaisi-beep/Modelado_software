import java.net.PasswordAuthentication;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Collections;

public class TestConnexion {
    //public static void main(String[]args){
    private static final  String URL = "jdbc:mysql://localhost:3306/ims?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC";
    private static final String USER = "javauser";
    private static final  String password = "12345";
       // String user = "javauser";// el usuario que creaste
        //String password = "12345"; //la contraseña que elegiste

    public static Connection getConnection() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            return DriverManager.getConnection(URL, USER, password);
        } catch (ClassNotFoundException | SQLException e) {
            System.out.println("Error al conectar: " + e.getMessage());
            return null;
        }
    }
    //metodo
    public static void  main (String[]args){
        Connection conn = getConnection();
        if (conn != null){
            System.out.println("conexion exitosa a la base de datos");
        }else {
            System.out.println("Error en la conexion");
        }

       // try {
         //   Connection conn = DriverManager.getConnection(url, user, password);
             //       "jdbc:mysql://localhost:3306/ims", "root", ""
           // System.out.println("conexion exitosa con la base datos javauser");
           // conn.close();
        //}catch (Exception e){
          //  System.out.println("error conexion: " + e.getMessage());
           // e.printStackTrace();
        //}
    }
}
