import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.sql.*;

public class ListarVentasReal extends JFrame {

    private JTable tablaVentas;
    private JTable tablaDetalle;
    private DefaultTableModel modeloVentas;
    private DefaultTableModel modeloDetalle;

    public ListarVentasReal() {
        setTitle("Listado de Ventas");
        setSize(900, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        modeloVentas = new DefaultTableModel(new String[]{"ID Venta", "Fecha", "Total"}, 0);
        tablaVentas = new JTable(modeloVentas);

        modeloDetalle = new DefaultTableModel(new String[]{"Producto", "Cantidad", "Precio Unit.", "Subtotal"}, 0);
        tablaDetalle = new JTable(modeloDetalle);

        JButton btnDetalle = new JButton("Ver Detalle");
        btnDetalle.addActionListener(this::verDetalle);

        JPanel panelBoton = new JPanel();
        panelBoton.add(btnDetalle);

        JSplitPane split = new JSplitPane(JSplitPane.VERTICAL_SPLIT,
                new JScrollPane(tablaVentas), new JScrollPane(tablaDetalle));
        split.setDividerLocation(250);

        add(split, BorderLayout.CENTER);
        add(panelBoton, BorderLayout.SOUTH);

        cargarVentas();
    }

    private void cargarVentas() {
        modeloVentas.setRowCount(0);

        String sql = "SELECT v.id, v.fecha, v.total FROM ventas v ORDER BY v.id DESC";

        try (Connection conn = TestConnexion.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                modeloVentas.addRow(new Object[]{
                        rs.getInt("id"),
                        rs.getString("fecha"),
                        rs.getDouble("total")
                });
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                    "Error al cargar ventas: " + e.getMessage());
        }
    }

    private void verDetalle(ActionEvent e) {
        int fila = tablaVentas.getSelectedRow();
        if (fila == -1) {
            JOptionPane.showMessageDialog(this, "Seleccione una venta.");
            return;
        }

        int idVenta = Integer.parseInt(modeloVentas.getValueAt(fila, 0).toString());
        cargarDetalle(idVenta);
    }

    private void cargarDetalle(int idVenta) {
        modeloDetalle.setRowCount(0);

        String sql =
                "SELECT p.nombre AS producto, " +
                        "dv.cantidad, " +
                        "dv.precio_unitario, " +
                        "dv.subtotal " +
                        "FROM detalle_ventas dv " +
                        "JOIN productos p ON dv.producto_id = p.id " +
                        "WHERE dv.venta_id = ?";

        try (Connection conn = TestConnexion.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, idVenta);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                modeloDetalle.addRow(new Object[]{
                        rs.getString("producto"),
                        rs.getInt("cantidad"),
                        rs.getDouble("precio_unitario"),
                        rs.getDouble("subtotal")
                });
            }

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this,
                    "Error al cargar detalle: " + ex.getMessage());
        }
    }
}