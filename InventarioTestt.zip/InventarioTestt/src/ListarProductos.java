import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;

public class ListarProductos extends JFrame {

    // ================================
    //        ATRIBUTOS
    // ================================
    private JTable tablaProductos;
    private DefaultTableModel modelo;

    private JTextField txtBuscar;
    private JComboBox<String> comboOrden;
    private JComboBox<String> comboCategoria;

    private JButton btnBuscar;
    private JButton btnFiltrar;
    private JButton btnActualizar;

    // ================================
    //        CONSTRUCTOR
    // ================================
    public ListarProductos() {

        setTitle("Listado de Productos");
        setSize(1100, 700);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());
        getContentPane().setBackground(new Color(240, 255, 240));

        // ----------- MODELO DE TABLA -------------
        modelo = new DefaultTableModel(new String[]{
                "N°", "ID", "Nombre", "Descripción", "Cantidad", "Precio", "Categoría"
        }, 0);

        tablaProductos = new JTable(modelo);
        tablaProductos.setRowHeight(26);
        tablaProductos.setFont(new Font("Segoe UI", Font.PLAIN, 13));

        JScrollPane scroll = new JScrollPane(tablaProductos);
        add(scroll, BorderLayout.CENTER);

        // ----------- COMPONENTES DE BÚSQUEDA -------------
        txtBuscar = new JTextField(15);
        btnBuscar = new JButton("Buscar");

        comboCategoria = new JComboBox<>(new String[]{
                "Todas", "Bebidas", "Golosinas", "Verdulería", "Carnes",
                "Juguetería", "Ferretería", "Librería", "Bijouterie", "Fiambres"
        });

        comboOrden = new JComboBox<>(new String[]{
                "Ordenar por...", "Precio ascendente", "Precio descendente",
                "Cantidad ascendente", "Cantidad descendente"
        });

        btnFiltrar = new JButton("Filtrar");
        btnActualizar = new JButton("Actualizar");

        // ===============================
        //       PANEL SUPERIOR (PASO 3)
        // ===============================
        JPanel panelSuperior = new JPanel(new FlowLayout(FlowLayout.LEFT));
        panelSuperior.setBackground(Color.WHITE);
        panelSuperior.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JLabel lblTitulo = new JLabel("Opciones de Búsqueda");
        lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 15));

        panelSuperior.add(lblTitulo);
        panelSuperior.add(new JLabel(" | Buscar: "));
        panelSuperior.add(txtBuscar);
        panelSuperior.add(btnBuscar);

        panelSuperior.add(new JLabel(" | Categoría: "));
        panelSuperior.add(comboCategoria);
        panelSuperior.add(btnFiltrar);

        panelSuperior.add(new JLabel(" | Ordenar por: "));
        panelSuperior.add(comboOrden);

        panelSuperior.add(btnActualizar);

        add(panelSuperior, BorderLayout.NORTH);

        // ===============================
        //       EVENTOS
        // ===============================
        btnActualizar.addActionListener(e -> cargarProductos());
        btnBuscar.addActionListener(e -> buscarProducto());
        btnFiltrar.addActionListener(e -> filtrarCategoria());
        comboOrden.addActionListener(e -> ordenarProductos());

        // Cargar datos iniciales
        cargarProductos();
    }

    // ================================
    //       MÉTODO DE CONEXIÓN
    // ================================
    private Connection conexion() throws SQLException {
        return DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/ims?useSSL=false&allowPublicKeyRetrieval=true",
                "javauser",
                "12345"
        );
    }

    // ================================
    //       CARGAR PRODUCTOS
    // ================================
    private void cargarProductos() {
        String sql = "SELECT * FROM productos ORDER BY id ASC";

        try (Connection conn = conexion();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            modelo.setRowCount(0);

            while (rs.next()) {

                int fila = modelo.getRowCount() + 1;

                modelo.addRow(new Object[]{
                        fila,
                        rs.getInt("id"),
                        rs.getString("nombre"),
                        rs.getString("descripcion"),
                        rs.getInt("cantidad"),
                        rs.getDouble("precio"),
                        rs.getString("categoria")
                });
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al cargar: " + e.getMessage());
        }
    }

    // ================================
    //       BUSCAR PRODUCTO
    // ================================
    private void buscarProducto() {
        String texto = txtBuscar.getText().trim();

        if (texto.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Ingrese algo para buscar.");
            return;
        }

        String sql = "SELECT * FROM productos WHERE nombre LIKE ? OR descripcion LIKE ?";

        try (Connection conn = conexion();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, "%" + texto + "%");
            ps.setString(2, "%" + texto + "%");

            ResultSet rs = ps.executeQuery();
            modelo.setRowCount(0);

            while (rs.next()) {
                int fila = modelo.getRowCount() + 1;

                modelo.addRow(new Object[]{
                        fila,
                        rs.getInt("id"),
                        rs.getString("nombre"),
                        rs.getString("descripcion"),
                        rs.getInt("cantidad"),
                        rs.getDouble("precio"),
                        rs.getString("categoria")
                });
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al buscar: " + e.getMessage());
        }
    }

    // ================================
    //       FILTRAR POR CATEGORÍA
    // ================================
    private void filtrarCategoria() {

        String categoria = comboCategoria.getSelectedItem().toString();

        String sql = "SELECT * FROM productos";

        if (!categoria.equals("Todas")) {
            sql += " WHERE categoria = '" + categoria + "'";
        }

        try (Connection conn = conexion();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            modelo.setRowCount(0);

            while (rs.next()) {
                int fila = modelo.getRowCount() + 1;

                modelo.addRow(new Object[]{
                        fila,
                        rs.getInt("id"),
                        rs.getString("nombre"),
                        rs.getString("descripcion"),
                        rs.getInt("cantidad"),
                        rs.getDouble("precio"),
                        rs.getString("categoria")
                });
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al filtrar: " + e.getMessage());
        }
    }

    // ================================
    //       ORDENAR PRODUCTOS
    // ================================
    private void ordenarProductos() {

        String opcion = comboOrden.getSelectedItem().toString();
        if (opcion.equals("Ordenar por...")) return;

        String sql = "SELECT * FROM productos ";

        switch (opcion) {
            case "Precio ascendente":
                sql += "ORDER BY precio ASC";
                break;
            case "Precio descendente":
                sql += "ORDER BY precio DESC";
                break;
            case "Cantidad ascendente":
                sql += "ORDER BY cantidad ASC";
                break;
            case "Cantidad descendente":
                sql += "ORDER BY cantidad DESC";
                break;
        }

        try (Connection conn = conexion();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            modelo.setRowCount(0);

            while (rs.next()) {
                int fila = modelo.getRowCount() + 1;

                modelo.addRow(new Object[]{
                        fila,
                        rs.getInt("id"),
                        rs.getString("nombre"),
                        rs.getString("descripcion"),
                        rs.getInt("cantidad"),
                        rs.getDouble("precio"),
                        rs.getString("categoria")
                });
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al ordenar: " + e.getMessage());
        }
    }
}

//import com.itextpdf.text.*;
//import com.itextpdf.text.Font;
//import com.itextpdf.text.pdf.PdfPCell;
//import com.itextpdf.text.pdf.PdfWriter;
//import com.itextpdf.text.pdf.PdfPTable;


//import java.io.*;
//public class ListarProductos extends JFrame {
  //  private JPanel panelPrincipal;
    //private JTable tablaProductos;
   // private DefaultTableModel modeloTabla;

    //public ListarProductos() {
      //  setTitle("Lista de Productos");
       // setSize(60, 300);
        //setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        //setLocationRelativeTo(null);

        //configurar la tabla, CREAR TABLA Y MODELO
        //modeloTabla = new DefaultTableModel(new String[]{"ID", "NOMBRE", "DESCRIPCION", "CANTIDAD", "PRECIO"}, 0);

        //modeloTabla.addColumn("ID");
        //modeloTabla.addColumn("NOMBRE");
        //modeloTabla.addColumn("DESCRIPCION");
        //modeloTabla.addColumn("CANTIDAD");
        //modeloTabla.addColumn("PRECIO");

//        tablaProductos = new JTable(modeloTabla);
  //      JScrollPane scroll = new JScrollPane(tablaProductos);
        //add(new JScrollPane(tablaProductos));

        //Panel principal
    //    panelPrincipal = new JPanel(new BorderLayout());

        //Panel  de busqueda
      //  JPanel panelBuscar = new JPanel();
       // panelBuscar.setLayout(new FlowLayout());

        //JLabel lblBuscar = new JLabel("Buscar: ");
        //JTextField txtBuscar = new JTextField(15);
        //JButton btnBuscar = new JButton("Buscar");
        //JButton btnMostrarTodo = new JButton("Mostrar Todo");

        //Nuevo Combox para ordenar
        //String[] opcionesOrden = {"Ordenar por ....", "Precio ascendente", "Precio descendente", "Cantidad ascendente", "Cantidad descendente"};
        //JComboBox<String> comboOrden = new JComboBox<>(opcionesOrden);
        //panelBuscar.add(comboOrden);


        //agregamos los elementos al panel de busqueda
        //panelBuscar.add(lblBuscar);
        //panelBuscar.add(txtBuscar);
        //panelBuscar.add(btnBuscar);
        //panelBuscar.add(btnMostrarTodo);

        //importante agregamos el panel de busqueda al panel principal
        //panelPrincipal.add(panelBuscar, BorderLayout.NORTH);

        //Accion del bototn buscar
        //btnBuscar.addActionListener(e->{
          //  String textoBusqueda = txtBuscar.getText().trim();

            //if (textoBusqueda.isEmpty()){
                //JOptionPane.showMessageDialog(null, "Ingrese un nombre o descripcion para buscar.");
              //  JOptionPane.showMessageDialog(null, "Ingrese un texto para buscar. ");
                //return;
            //}

            //try (Connection conn = DriverManager.getConnection(
              //      "jdbc:mysql://localhost:3306/ims?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone= UTC",
                //    "javauser","12345"
            //)){
              //  String sql = "SELECT * FROM productos WHERE nombre LIKE ? OR descripcion LIKE ?";
                //PreparedStatement ps = conn.prepareStatement(sql);
                //ps.setString(1,"%" + textoBusqueda + "%");
                //ps.setString(2, "%" + textoBusqueda + "%");

                //ResultSet rs = ps.executeQuery();
                //DefaultTableModel modelo = (DefaultTableModel) tablaProductos.getModel();
                //modelo.setRowCount(0);//limpia la tabla

                //while (rs.next()) {
                    //Object[] fila = {
                  //  modelo.addRow(new Object[]{
                    //        rs.getInt("id"),
                      //      rs.getString("nombre"),
                        //    rs.getString("descripcion"),
                          //  rs.getInt("cantidad"),
                            //rs.getDouble("precio")
                    //});
                    //modeloTabla.addRow(fila);
                //}

                //if (modeloTabla.getRowCount() == 0){
                  //  JOptionPane.showMessageDialog(null, "Nose emcontraron productos con ese criterio. ");
                //}
                //rs.close();
                //ps.close();
                //conn.close();

            //}catch (Exception ex){
              //  JOptionPane.showMessageDialog(null, "Error al buscar producto: " + ex.getMessage());
            //}

        //});

        //Agregar logica del ordenamiento
        //comboOrden.addActionListener(e->{
          //  String seleccion = (String) comboOrden.getSelectedItem();
            //String sql = "SELECT * FROM productos" + "ORDER BY precio ASC";
            //String sql = "SELECT * FROM productos ";

            //String opcion = comboOrden.getSelectedItem().toString();

            //if (opcion.equals("Precio ascendente")){
              //  sql += "ORDER BY precio ASC";
            //} else if (opcion.equals("Precio descendente")) {
              //  sql += "ORDER BY precio DESC";
            //} else if (opcion.equals("Cantidad ascendente")) {
              //  sql += "ORDER BY cantidad ASC";
            //} else if (opcion.equals("Cantidad descendente")) {
              //  sql += "ORDER BY cantidad DESC";
            //}

            //switch (seleccion){
              //  case "Precio ascendente":
                //    sql += "ORDER BY precio ASC";
                  //  break;
                //case "Precio descendente":
                  //  sql += "ORDER BY precio DESC";
                    //break;
               // case "Cantidad ascendete":
                 //   sql += "ORDER BY cantidad ASC";
                  //  break;
                //case "Cantidad descendente":
                  //  sql += "ORDER BY cantidad DESC";
                    //break;
                //default:
                  //  break;
            //}

            //try {
              //  Class.forName("com.mysql.cj.jdbc.Driver");

            //try (Connection conn = DriverManager.getConnection(
              //      "jdbc:mysql://localhost:3306/ims?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC",
                //    "javauser","12345"
            //)) {

              //  Statement stmt = conn.createStatement();
                //ResultSet rs = stmt.executeQuery(sql);
                //DefaultTableModel modelo = (DefaultTableModel) tablaProductos.getModel();
                //modelo.setRowCount(0);

                //while (rs.next()) {
                  //  Object[]fila ={
                    //        rs.getInt("id"),
                      //      rs.getString("nombre"),
                        //    rs.getString("descripcion"),
                          //  rs.getInt("cantidad"),
                           // rs.getDouble("precio")
                    //};
                    //modelo.addRow(fila);
                //}
               // }
            //}catch (SQLException | ClassNotFoundException ex){
              //  JOptionPane.showMessageDialog(null,"Error al ordenar productos: "+ ex.getMessage());
            //}
        //});
        //btnMostrarTodo.addActionListener(e-> cargarProductos());

        //Panel de busqueda
        //JPanel panelBuscar = new JPanel();
        //JLabel lblBuscar = new JLabel("Buscar:");
        //JTextField txtBuscar = new JTextField(20);
        //JButton btnBuscar = new JButton("Buscar");
        //JButton btnMostrarTodo = new JButton("Mostrar todo");

        //panelBuscar.add(lblBuscar);
        //panelBuscar.add(txtBuscar);
        //panelBuscar.add(btnBuscar);
        //panelBuscar.add(btnMostrarTodo);

        //CREAR EL PANEL
        //JPanel panelBoton= new JPanel();

        //CREAR BOTON ACTUALIZAR
        //JButton btnActualizar = new JButton("ACTUALIZAR");
        //btnActualizar.addActionListener(e -> cargarProductos());
        //panelBoton.add(btnActualizar);

        //crear boton eliminar
        //JButton btnEliminar = new JButton("ELIMINAR");
        //panelBoton.add(btnEliminar);

        //crear boton editar
        //JButton btnEditar = new JButton("EDITAR");
        //panelBoton.add(btnEditar);

        //accion del boton
        //btnEditar.addActionListener(e->{
          //  int fila = tablaProductos.getSelectedRow();
           // if ( fila == -1){
             //   JOptionPane.showMessageDialog(null, "seleccione un producto para editar.");
               // return;
            //}
            //int id = Integer.parseInt(tablaProductos.getValueAt(fila, 0).toString());
            //String nombreActual = tablaProductos.getValueAt(fila, 1).toString();
            //String descripcionActual = tablaProductos.getValueAt(fila, 2).toString();
            //int cantidadActual = Integer.parseInt(tablaProductos.getValueAt(fila, 3).toString());
            //double precioActual = Double.parseDouble(tablaProductos.getValueAt(fila, 4).toString());

            //JTextField txtNOMBRE = new JTextField(nombreActual);
            //JTextField txtDescripcion = new JTextField(descripcionActual);
            //JTextField txtCantidad = new JTextField(String.valueOf(cantidadActual));
            //JTextField txtPrecio = new JTextField(String.valueOf(precioActual));

            //Object[] campos = {
              //      "Nombre: ", txtNOMBRE,
                //    "Descripcion: ", txtDescripcion,
                  //  "Cantidad: ", txtCantidad,
                    //"Precio: ", txtPrecio
            //};
            //int opcion = JOptionPane.showConfirmDialog(null, campos, "Editar producto", JOptionPane.OK_CANCEL_OPTION);

            //if (opcion ==JOptionPane.OK_OPTION) {
              //  String nuevoNombre = txtNOMBRE.getText().trim();
               // String nuevaDescripcion = txtDescripcion.getText().trim();
               // String cantidadStr = txtCantidad.getText().trim();
               // String precioStr = txtPrecio.getText().trim();

                //if (nuevoNombre.isEmpty() || nuevaDescripcion.isEmpty() || cantidadStr.isEmpty() || precioStr.isEmpty()) {
                  //  JOptionPane.showMessageDialog(null, "Todos los campos son obligatorios.");
                   // return;
                //}
                //int cantidad;
                //double precio;

                //try {

                  //  int nuevaCantidad = Integer.parseInt(cantidadStr);
                   // double nuevoPrecio = Double.parseDouble(precioStr);

                    //}
                    //if (cantidad<0||precio<0){
                    //  JOptionPane.showMessageDialog(null, "La cantidad y el precio deben ser positivos", "Error", JOptionPane.ERROR_MESSAGE);
                    //return;
                    //}
                    //}catch (NumberFormatException ex){
                    //
                    //  JOptionPane.showMessageDialog(null, "Cantidad o precio invalido. ", "Error", JOptionPane.ERROR_MESSAGE);
                    //return;
                    //}
                    //}
                    //if (opcion == JOptionPane.OK_OPTION){
                   // try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/ims?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC", "javauser", "12345")) {

                        //TOMAR LOS NUEVOS VALORES
                        //String nuevoNombre = txtNOMBRE.getText();
                        //    String nuevaDescripcion = txtDescripcion.getText();
                        //  int nuevaCantidad = Integer.parseInt(txtCantidad.getText());
                        //double nuevoPrecio = Double.parseDouble(txtPrecio.getText());

                     //   String sql = "UPDATE productos SET nombre=?, descripcion=?, cantidad=?, precio=? where id=?";
                        //String sql = "INSERT INTO productos (nombre, descripcion, cantidad, precio) VALUES (?,?,?,?)";
                       // PreparedStatement ps = conn.prepareStatement(sql);
                       // ps.setString(1, nuevoNombre);
                       // ps.setString(2, nuevaDescripcion);
                       // ps.setInt(3, nuevaCantidad);
                       // ps.setDouble(4, nuevoPrecio);
                       // ps.setInt(5, id);

                        //ps.executeUpdate();

                        //int filas = ps.executeUpdate();
                        //if (filas > 0) {
                          //  JOptionPane.showMessageDialog(null, "Producto actualizadp correctamente. ");
                            //}
                            //JOptionPane.showMessageDialog(null, "Producto agregado correctamente");
                            //cargarProductos();//refresca
                        //} else {
                          //  JOptionPane.showMessageDialog(null, "Np se puede actualizar el producto");
                        //}
                    //}
                //} catch (NumberFormatException ex) {
                  //  JOptionPane.showMessageDialog(null, "Cantidad y precio deben ser numero validos. ");
                    // + ex.getMessage());
                //} catch (SQLException ex) {

                  //  JOptionPane.showMessageDialog(null, "Error al actualizar" + ex.getMessage());
                //}
            //}
        //});

        //agregar el panle al marco
        //getContentPane().add(panelBoton, BorderLayout.SOUTH);

        //ACCION DEL BOTON ELIMINAR
        //btnEliminar.addActionListener(e ->{
          //  int fila = tablaProductos.getSelectedRow();
           // if (fila== -1){
             //   JOptionPane.showMessageDialog(null, "Selecione un producto para eliminar.");
               // return;
            //}
            //int id = Integer.parseInt(tablaProductos.getValueAt(fila, 0).toString());

            //int confirm = JOptionPane.showConfirmDialog(
              //      null,
                //    "seguro que desea eliminar este producto?",
                  //  "confirmar eliminacion",
                    //JOptionPane.YES_NO_OPTION
            //);
            //if (confirm ==JOptionPane.YES_OPTION){
              //  try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/ims?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC","javauser","12345")){
                //    String sql = "DELETE FROM PRODUCTOS WHERE id= ?";
                  //  PreparedStatement ps = conn.prepareStatement(sql);
                    //ps.setInt(1, id);
                    //ps.executeUpdate();

                    //modeloTabla.removeRow(fila);
                    //JOptionPane.showMessageDialog(null, "PRODUCTO ELIMINADO CORRECTAMENTE.");
                //}catch (SQLException ex){
                  //  JOptionPane.showMessageDialog(null,"ERROR AL ELIMINAR: " + ex.getMessage());
               // }
            //}
        //});
        //JButton btnAgregar = new JButton("AGREGAR");
        //panelBoton.add(btnAgregar);

        //btnAgregar.addActionListener(e->{
          //  JTextField txtNombre = new JTextField();
            //JTextField txtDescripcion = new JTextField();
            //JTextField txtCantidad = new JTextField();
            //JTextField txtPrecio = new JTextField();

            //Object[] campos ={
              //      "Nombre: ", txtNombre,
                //    "Descripcion: ", txtDescripcion,
                  //  "Cantidad: ", txtCantidad,
                    //"Precio: ", txtPrecio,
            //};
            //int opcion = JOptionPane.showConfirmDialog(
              //      null,
                //    campos,
                  //  "Agregar nuevo producto",
                    //JOptionPane.OK_CANCEL_OPTION
            //);
            //if (opcion == JOptionPane.OK_OPTION) {
                //validacion 1
              //  if (txtNombre.getText().trim().isEmpty() ||
                //        txtDescripcion.getText().trim().isEmpty() ||
                  //      txtCantidad.getText().trim().isEmpty() ||
                    //    txtPrecio.getText().trim().isEmpty()) {

                    //JOptionPane.showMessageDialog(null, "Todos los campos son obligatorios. ");
                    //return;
                //}
                //Validacion 2
                //int cantidad;
                //double precio;

                //try {
                  //  cantidad = Integer.parseInt(txtCantidad.getText().trim());
                    //precio = Double.parseDouble(txtPrecio.getText().trim());

                    //if (cantidad <= 0 || precio <= 0) {
                      //  JOptionPane.showMessageDialog(null, "La cantidad y el precio deben ser mayores a");
                        //return;
                    //}
                //}catch (NumberFormatException ex){
                  //  JOptionPane.showMessageDialog(null, "Cantidad y precio deben ser numericos");
                   // return;
            //}
                //si todo esta bien se guarda en la base de datos
              //  try (Connection conn = DriverManager.getConnection(
                //        "jdbc:mysql://localhost: 3306/ims?useSSL =false&serverTimezone=UTC",
                  //      "javauser","12345")) {
                    //String sql = "INSERT INTO productos (nombre, descripcion, cantidad, precio) VALUES (?,?,?,?)";
                    //PreparedStatement ps =conn.prepareStatement(sql);
                    //ps.setString(1, txtNombre.getText());
                    //ps.setString(2, txtDescripcion.getText());
                    //ps.setInt(3, cantidad);
                    //ps.setDouble(4,precio);

                    //ps.executeUpdate();
                    //int filas = ps.executeUpdate();

                    //if (filas>0){
                      //  JOptionPane.showMessageDialog(null, "Producto agregado correctamente");
                        //cargarProductos();//refresca la tabla
                    //}else {
                      //  JOptionPane.showMessageDialog(null, "No se pudo agregar el producto");
                    //}

                //}catch (SQLException ex){
                  //  JOptionPane.showMessageDialog(null,"Error al agregar producto: " + ex.getMessage());
                //}
            //}
        //});
        //JButton btnExportar = new JButton("EXPORTAR CSV");
        //btnExportar.addActionListener(e-> exportarCSV());
        //panelBoton.add(btnExportar);

        //Buscar boton
        //btnBuscar.addActionListener(e->{
          //  String texto = txtBuscar.getText().trim();

            //if (texto.isEmpty()) {

              //  JOptionPane.showMessageDialog(null, "Ingrese un texto para buscar. ");
               // return;
            //}
            //try (Connection conn = DriverManager.getConnection(
              //      "jdbc:mysql://localhost:3306/ims?useSSL=false&allowOublicKeyRetrieval=true&serverTimezone= UTC",
                //    "javauser", "12345")){
                //String sql = " SELECT * FROM productos WHERE nombre LIKE ? OR descripcion LIKE ?";
                //PreparedStatement ps = conn.prepareStatement(sql);
                //ps.setString(1,"%" + texto + "%");
                //ps.setString(2, "%"+ texto + "%");

                //ResultSet rs = ps.executeQuery();

                //DefaultTableModel modelo = (DefaultTableModel) tablaProductos.getModel();
                //modelo.setRowCount(0);//limpia tabla

                //while (rs.next()){
                  //  Object[]fila = {
                    //        rs.getInt("id"),
                      //      rs.getString("nombre"),
                        //    rs.getString("descripcion"),
                          //  rs.getInt("cantidad"),
                            //rs.getDouble("precio")
                    //};
                    //modelo.addRow(fila);
                //}
                //if (modelo.getRowCount()==0){
                  //  JOptionPane.showMessageDialog(null, "Nose encontraron productos con ese nombre");
                //}
            //}catch (SQLException ex){
              //  JOptionPane.showMessageDialog(null,"Error en la busqueda: "+ ex.getMessage());
            //}
        //});
        //JButton btnPDF = new JButton("EXPORTAR PDF");
        //panelBoton.add(btnPDF);

        //btnPDF.addActionListener(e-> {
          //          try {
            //            //CREAR DOCUMENTO PDF
              //          //String rutaArchivo = "Reporte_inventario.pdf";
                        //com.itextpdf.text.Document documento = new  com.itextpdf.text.Document();

                //        String ruta = System.getProperty("user.dir") + File.separator + "Reporte_inventario.pdf";

                  //      Document documento = new Document(PageSize.A4);
                    //    PdfWriter.getInstance(documento, new FileOutputStream(ruta));
                        //Document documento = new  Document();
                        //PdfWriter.getInstance(documento, new FileOutputStream("productos.pdf"));
                      //  documento.open();

                        //TITULO ENCABEZADO CON ESTILO
                        //Font tituloFont = new Font(Font.FontFamily.HELVETICA, 20, Font.BOLD,
                          //      new BaseColor(33, 150, 243));
                        //Font fechaFont = new Font(Font.FontFamily.HELVETICA, 10, Font.ITALIC, BaseColor.GRAY);

                        //Paragraph titulo = new Paragraph("SISTEMA DE INVENTARIO", tituloFont);
                        //titulo.setAlignment(Element.ALIGN_CENTER);
                        //documento.add(titulo);

                        //Paragraph fecha = new Paragraph("Geenrado: " + new java.util.Date(), fechaFont);
                        //fecha.setAlignment(Element.ALIGN_CENTER);
                        //documento.add(fecha);

                        //documento.add(Chunk.NEWLINE);

                        //titulo
                        //documento.add(new Paragraph("Reporte de Inventario", FontFactory.getFont(FontFactory.HELVETICA_BOLD, Font.BOLD)));
                        //documento.add(new Paragraph("Fecha: "+ new java.util.Date()));
                        //documento.add(new Paragraph(" "));//espacio
                        //documento.add(new Paragraph(" "));

                        //fecha
                        //String fecha = new java.text.SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(new java.util.Date());
                        //com.itextpdf.text.Font fechaFont = new com.itextpdf.text.Font(
                        //      com.itextpdf.text.Font.FontFamily.HELVETICA, 10,
                        //    com.itextpdf.text.Font.ITALIC,
                        //  new  com.itextpdf.text.BaseColor(100,100,100));
                        //com.itextpdf.text.Paragraph fechaParrafo = new com.itextpdf.text.Paragraph("Generado el: "+ fecha, fechaFont);
                        //fechaParrafo.setAlignment(com.itextpdf.text.Element.ALIGN_RIGHT);
                        //documento.add(fechaParrafo);
                        //documento.add(new com.itextpdf.text.Paragraph(" ")); //espacio

                        //crear tabla de datos.....con 5 columnas....COLOR CELESTE
                        //PdfPTable tabla = new PdfPTable(tablaProductos.getColumnCount());
                        //tabla.setWidthPercentage(100);
                        //tabla.setSpacingBefore(10f);
                        //tabla.setSpacingAfter(10f);

                        //tabla.addCell("ID");
                        //tabla.addCell("Nombre");
                        //tabla.addCell("Descripcion");
                        //tabla.addCell("Cantidad");
                        //tabla.addCell("Precio");

                        //Encabezados....llenar con datos de la tabla de la interfaz
                        //String[] columnas ={ "ID", "Nombre","Descripcion", "Cantidad", "Precio"};
                        //for (String col : columnas) {
                        //  com.itextpdf.text.pdf.PdfPCell celda = new  com.itextpdf.text.pdf.PdfPCell(new com.itextpdf.text.Phrase(col));
                        // celda.setBackgroundColor(new com.itextpdf.text.BaseColor(220,230,241));
                        //celda.setHorizontalAlignment(com.itextpdf.text.Element.ALIGN_CENTER);
                        //celda.setPadding(8);
                        //tabla.addCell(celda);
                        //ESTILO ENCABEZADO
                        //Font encabezadoFont = new Font(Font.FontFamily.HELVETICA, 12, java.awt.Font.BOLD, BaseColor.WHITE);
                        //BaseColor colorEncabezado = new BaseColor(33, 150, 243);
                        //for (int i = 0; i < tablaProductos.getColumnCount(); i++) {
                          //  PdfPCell celdaEncabezado = new PdfPCell(new Phrase(tablaProductos.getColumnName(i), encabezadoFont));
                            //celdaEncabezado.setBackgroundColor(colorEncabezado);
                            //celdaEncabezado.setHorizontalAlignment(Element.ALIGN_CENTER);
                            //celdaEncabezado.setPadding(5);
                            //tabla.addCell(celdaEncabezado);
                        //}
                        //cuerpo
                        //Font cuerpoFont = new Font(Font.FontFamily.HELVETICA, 10, Font.NORMAL, BaseColor.BLACK);

                        //for (int i = 0; i < tablaProductos.getColumnCount(); i++) {
                          //  for (int j = 0; j < tablaProductos.getColumnCount(); j++){
                            //PdfPCell celda = new PdfPCell(new Phrase(tablaProductos.getValueAt(i,j).toString()));
                            //celda.setHorizontalAlignment(Element.ALIGN_CENTER);
                            //celda.setPadding(5);
                            //tabla.addCell(celda);
                        //}
                    //}

                    //  Object valor = tablaProductos.getValueAt(i, j);
                    //tabla.addCell(valor != null ? valor.toString() : "");

                    //contenido
                    //DefaultTableModel modelo = (DefaultTableModel) tablaProductos.getModel();
                    //for (int i = 0; i < modelo.getRowCount(); i++){
                    //  for (int j = 0; j < modelo.getColumnCount(); j++){
                    //String valor = modelo.getValueAt(i,j).toString();
                    //com.itextpdf.text.pdf.PdfPCell celda = new com.itextpdf.text.pdf.PdfPCell(new com.itextpdf.text.Phrase(valor));
                    //celda.setPadding(6);
                    //    tabla.addCell(modelo.getValueAt(i,j).toString());
                    //}

                    //documento.add(tabla);

                //documento.add(Chunk.NEWLINE);

                 //Paragraph firma = new Paragraph("Inventario generado automaticamnete - " +
                   //      System.getProperty("user_name"), new Font(Font.FontFamily.HELVETICA,9,Font.ITALIC, BaseColor.GRAY));
                 //firma.setAlignment(Element.ALIGN_RIGHT);
                 //documento.add(firma);

                 //documento.close();

                //mensaje final
                //com.itextpdf.text.Font pieFont = new com.itextpdf.text.Font(
                  //      com.itextpdf.text.Font.FontFamily.HELVETICA,10,
                    //    com.itextpdf.text.Font.ITALIC,
                      //  new  com.itextpdf.text.BaseColor(100,100,100));
                //com.itextpdf.text.Paragraph pie = new com.itextpdf.text.Paragraph("0" + java.time.Year.now() + "SISTEMA DE INVENTARIO", pieFont);
                //pie.setAlignment(com.itextpdf.text.Element.ALIGN_CENTER);
                //documento.add(pie);

                //documento.close();

                //javax.swing.JOptionPane.showMessageDialog(null, "PDF generado correctamnete:"+ rutaArchivo);

                //File archivo = new File(ruta);
                //if (archivo.exists()) {
                   // JOptionPane.showMessageDialog(null, "PDF generado correctamente en: " + ruta);
                   //esktop.getDesktop().open(archivo);
                //lse {
                  //JOptionPane.showMessageDialog(null,"No se encontro el archivo PDF en la ruta" + ruta);
                //
                //agregar tabla al documneto
                //documento.add(tabla);
                //documento.close();

                //JOptionPane.showMessageDialog(null, "PDF generado correctamente(producto.pdf)");
            //}catch (Exception ex){
              //  javax.swing.JOptionPane.showMessageDialog(null, "Error al gegerar PDF" + ex.getMessage());
            //}
        //});
        //JButton btnClientes = new JButton("CLIENTES");
        //panelBoton.add(btnClientes);
        //btnClientes.addActionListener(e->{
          //  ListarClientes ventanaClientes = new ListarClientes();
            //ventanaClientes.setVisible(true);
        //});
        //JButton btnProveedores = new JButton("PROVEEDORES");
        //panelBoton.add(btnProveedores);
        //btnProveedores.addActionListener(e->{
          //  ListarProveedores ventanaProveedores = new ListarProveedores();
            //ventanaProveedores.setVisible(true);
        //});

        //btnMostrarTodo.addActionListener(e->{
          //  cargarProductos(); //vuelve a mostrar todos los productos
        //});

        //panelPrincipal.add(new JScrollPane(tablaProductos), BorderLayout.CENTER);
        //panelPrincipal.add(panelBoton, BorderLayout.SOUTH);

        //panel inferior del boton
        //JPanel panelBoton = new JPanel();
        //panelBoton.add(btnActualizar);

        //layout general
        //getContentPane().add(scroll, BorderLayout.CENTER);
        //getContentPane().add(panelBoton, BorderLayout.SOUTH);

        //CARGAR DATOS DE LA BASE DE DATOS
        //cargarProductos();
    //}
    //

    //private void cargarProductos() {
      //  try (Connection conn = DriverManager.getConnection(
        //            "jdbc:mysql://localhost:3306/ims?useSSL=false&serverTimezone=UTC","javauser","12345")){
            //CONSULTA SQL
            //modeloTabla.setRowCount(0); // Limpia la tabla antes de volver a cargar
            //String sql = "SELECT * FROM productos";
          //  Statement stmt = conn.createStatement();
           // ResultSet rs = stmt.executeQuery("SELECT * FROM productos");

            //limpiar tabla
            //DefaultTableModel modelo = (DefaultTableModel) tablaProductos.getModel();
            //modelo.setRowCount(0);

            //modeloTabla.setRowCount(0); //LIMPA LA TABLA ANYRS DE LLENAR
            //ejecuta
            //Statement stmt = conn.createStatement();
            //ResultSet rs = stmt.executeQuery("SELECT * FROM productos");

            //llenar tabla
            //while (rs.next()) {
              //  Object[] fila = {
                //        rs.getInt("ID"),
                  //      rs.getString("Nombre"),
                    //    rs.getString("Descripcion"),
                      //  rs.getInt("Cantidad"),
                        //rs.getDouble("Precio"),
           // };
             //   modelo.addRow(fila);
            //}
            //refresca
            //modelo.fireTableDataChanged();
            //rs.close();

            //st.close();
            //conn.close();
        //} catch (Exception e) {
          //  JOptionPane.showMessageDialog(null, "error al cargar productos: " + e.getMessage());
       // }
        //add(panelPrincipal);
        //setTitle("Listar de productos");
        //setSize(800,500);
        //setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        //setLocationRelativeTo(null);
        //setVisible(true);}

    //private void exportarCSV(){
      //  JFileChooser fileChooser = new JFileChooser();
        //fileChooser.setDialogTitle("Guardar archivo CSV");

        //int seleccion = fileChooser.showSaveDialog(this);
        //if (seleccion == JFileChooser.APPROVE_OPTION){
          //  File archivo = fileChooser.getSelectedFile();

            //try (PrintWriter pw = new PrintWriter(new FileWriter(archivo + ".csv"))){

                //escribir encabezados
              //  pw.println("IdProducto, Nombre, Descripcion, Cantidad, Precio");

                //recorrer la tabla y escribir los datos
                //for (int i = 0; i < tablaProductos.getRowCount(); i++){
                  //  pw.println(
                    //        tablaProductos.getValueAt(i,0) + ","+
                      //              tablaProductos.getValueAt(i,1) + "," +
                        //            tablaProductos.getValueAt(i,2) + "," +
                          //          tablaProductos.getValueAt(i,3) + "," +
                            //        tablaProductos.getValueAt(i, 4)
                    //);
                //}

                //JOptionPane.showMessageDialog(this, "Archivo exportado correctamnete. ");
            //}catch (IOException ex){
              //  JOptionPane.showMessageDialog(this, "Error al exportar: " + ex.getMessage());
            //}

        //}
    //}

    //public static void main(String[] args) {
      //  SwingUtilities.invokeLater(() ->
        //        new ListarProductos().setVisible(true));
    //}
//}