import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.io.FileOutputStream;

import com.toedter.calendar.JDateChooser;
import com.itextpdf.text.Document;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Element;
import com.itextpdf.text.Image;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.text.BaseColor;

public class ListarVentas extends JFrame {

    private JTable tablaVentas;
    private DefaultTableModel modeloTabla;
    private JDateChooser fechaInicio;
    private JDateChooser fechaFin;
    private JButton btnFiltrar;
    private JButton btnMostrarTodo;
    private JButton btnExportarPDF;

    public ListarVentas() {
        setTitle("Listado de Ventas");
        setSize(900, 550);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        // PANEL FONDO CON DEGRADADO
        JPanel panelFondo = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                GradientPaint gp = new GradientPaint(
                        0, 0, new Color(224, 247, 250),
                        0, getHeight(), new Color(200, 255, 229)
                );
                g2d.setPaint(gp);
                g2d.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        panelFondo.setLayout(new BorderLayout());
        add(panelFondo);

        // TÍTULO
        JLabel lblTitulo = new JLabel("LISTADO DE VENTAS", SwingConstants.CENTER);
        lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 26));
        lblTitulo.setForeground(new Color(0, 102, 204));
        lblTitulo.setBorder(BorderFactory.createEmptyBorder(15, 0, 15, 0));
        panelFondo.add(lblTitulo, BorderLayout.NORTH);

        // TABLA
        modeloTabla = new DefaultTableModel(new String[]{
                "ID", "Total", "Fecha"
        }, 0);
        tablaVentas = new JTable(modeloTabla);
        JScrollPane scroll = new JScrollPane(tablaVentas);
        panelFondo.add(scroll, BorderLayout.CENTER);

        // PANEL FILTROS (FECHAS y BOTONES)
        JPanel panelFiltros = new JPanel(new FlowLayout());
        panelFiltros.setOpaque(false);

        panelFiltros.add(new JLabel("Desde:"));
        fechaInicio = new JDateChooser();
        fechaInicio.setPreferredSize(new Dimension(120, 25));
        panelFiltros.add(fechaInicio);

        panelFiltros.add(new JLabel("Hasta:"));
        fechaFin = new JDateChooser();
        fechaFin.setPreferredSize(new Dimension(120, 25));
        panelFiltros.add(fechaFin);

        btnFiltrar = new JButton("Filtrar por fecha");
        btnMostrarTodo = new JButton("Mostrar todo");
        panelFiltros.add(btnFiltrar);
        panelFiltros.add(btnMostrarTodo);

        panelFondo.add(panelFiltros, BorderLayout.NORTH);

        // PANEL BOTONES INFERIORES (PDF)
        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        panelBotones.setOpaque(false);
        panelBotones.setBorder(BorderFactory.createEmptyBorder(10, 20, 20, 20));

        btnExportarPDF = new JButton("Exportar PDF");
        panelBotones.add(btnExportarPDF);

        panelFondo.add(panelBotones, BorderLayout.SOUTH);

        // ESTILO BOTONES
        Color colorBoton = new Color(0, 102, 204);
        Color colorTexto = Color.WHITE;
        Font fuenteBoton = new Font("Segoe UI", Font.BOLD, 13);

        for (JButton b : new JButton[]{btnFiltrar, btnMostrarTodo, btnExportarPDF}) {
            b.setBackground(colorBoton);
            b.setForeground(colorTexto);
            b.setFont(fuenteBoton);
            b.setFocusPainted(false);
            b.setBorder(BorderFactory.createEmptyBorder(8, 15, 8, 15));
            b.setCursor(new Cursor(Cursor.HAND_CURSOR));
        }

        // ACCIONES
        btnFiltrar.addActionListener(e -> filtrarPorFechas());
        btnMostrarTodo.addActionListener(e -> cargarVentas());
        btnExportarPDF.addActionListener(e -> exportarVentasPDF());

        // CARGAR DATOS AL INICIO
        cargarVentas();
    }

    // ---------------------- CONEXIÓN ----------------------

    private Connection getConnection() throws SQLException {
        // Si ya tenés una clase TestConnexion, podés usar:
        // return TestConnexion.getConnection();
        return DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/ims?useSSL=false&serverTimezone=UTC",
                "javauser", "12345"
        );
    }

    // ---------------------- CARGAR TODAS LAS VENTAS ----------------------

    private void cargarVentas() {
        modeloTabla.setRowCount(0);

        String sql =
                "SELECT v.id, v.total, v.fecha FROM ventas v ORDER BY v.id DESC";

        try (Connection conn = getConnection();
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) {
                modeloTabla.addRow(new Object[]{
                        rs.getInt("id"),
                        rs.getDouble("total"),
                        rs.getTimestamp("fecha")
                });
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error al cargar ventas: " + e.getMessage());
        }
    }

    // ---------------------- FILTRAR POR FECHAS ----------------------

    private void filtrarPorFechas() {
        if (fechaInicio.getDate() == null || fechaFin.getDate() == null) {
            JOptionPane.showMessageDialog(this, "Seleccione ambas fechas para filtrar.");
            return;
        }

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        String desde = sdf.format(fechaInicio.getDate());
        String hasta = sdf.format(fechaFin.getDate());

        modeloTabla.setRowCount(0);

        String sql =
                "SELECT v.id, v.total, v.fecha " +
                        "FROM ventas v " +
                        "WHERE DATE(v.fecha) BETWEEN ? AND?" +
                        "ORDER BY v.id DESC";

        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, desde);
            ps.setString(2, hasta);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                modeloTabla.addRow(new Object[]{
                        rs.getInt("id"),
                        rs.getDouble("total"),
                        rs.getTimestamp("fecha")
                });
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error al filtrar: " + e.getMessage());
        }
    }

    // ---------------------- EXPORTAR A PDF ----------------------

    private void exportarVentasPDF() {
        try {
            String ruta = System.getProperty("user.dir") + "/Reporte_Ventas.pdf";

            Document document = new Document(PageSize.A4.rotate()); // Horizontal
            PdfWriter.getInstance(document, new FileOutputStream(ruta));
            document.open();

            // LOGO (opcional)
            try {
                Image logo = Image.getInstance("src/imagenes/logo_tdb.png");
                logo.scaleToFit(80, 80);
                logo.setAlignment(Element.ALIGN_CENTER);
                document.add(logo);
                document.add(Chunk.NEWLINE);
            } catch (Exception ex) {
                System.out.println("Logo no encontrado, continúo sin imagen.");
            }

            // TÍTULO
            Paragraph titulo = new Paragraph("REPORTE DE VENTAS");
            titulo.setAlignment(Element.ALIGN_CENTER);
            document.add(titulo);

            // FECHA
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
            Paragraph fecha = new Paragraph("Generado el: " + sdf.format(new java.util.Date()));
            fecha.setAlignment(Element.ALIGN_CENTER);
            document.add(fecha);

            document.add(Chunk.NEWLINE);

            // TABLA
            PdfPTable table = new PdfPTable(modeloTabla.getColumnCount());
            table.setWidthPercentage(100);

            // Encabezados
            for (int i = 0; i < modeloTabla.getColumnCount(); i++) {
                PdfPCell celda = new PdfPCell(new Paragraph(modeloTabla.getColumnName(i)));
                celda.setBackgroundColor(new BaseColor(173, 216, 230));
                celda.setHorizontalAlignment(Element.ALIGN_CENTER);
                celda.setPadding(5);
                table.addCell(celda);
            }

            // Datos
            for (int i = 0; i < modeloTabla.getRowCount(); i++) {
                for (int j = 0; j < modeloTabla.getColumnCount(); j++) {
                    Object valor = modeloTabla.getValueAt(i, j);
                    PdfPCell celda = new PdfPCell(new Paragraph(
                            valor != null ? valor.toString() : "")
                    );
                    celda.setHorizontalAlignment(Element.ALIGN_CENTER);
                    celda.setPadding(4);
                    table.addCell(celda);
                }
            }

            document.add(table);

            document.add(Chunk.NEWLINE);
            Paragraph footer = new Paragraph("Sistema de Inventario - " + java.time.Year.now());
            footer.setAlignment(Element.ALIGN_CENTER);
            document.add(footer);

            document.close();

            JOptionPane.showMessageDialog(this, "PDF generado correctamente en: " + ruta);

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error al generar PDF: " + e.getMessage());
        }
    }

    // MAIN SOLO PARA PROBAR ESTA VENTANA
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new ListarVentas().setVisible(true));
    }
}

//import com.itextpdf.text.*;
//import com.itextpdf.text.Image;
//import com.itextpdf.text.BaseColor;
//import com.itextpdf.text.Paragraph;
//import com.itextpdf.text.Element;
//import com.itextpdf.text.pdf.*;
//import com.itextpdf.text.pdf.PdfPCell;
//import com.itextpdf.text.pdf.PdfPTable;
//import com.itextpdf.text.pdf.PdfWriter;
//import com.toedter.calendar.JDateChooser;
//import com.itextpdf.text.Document;
//import com.itextpdf.text.DocumentException;
//import com.itextpdf.text.Font;
//import com.itextpdf.text.Font.FontFamily;
//import com.itextpdf.text.Phrase;
//import javax.naming.NamingEnumeration;
//import javax.swing.*;
//import javax.swing.table.DefaultTableModel;
//import java.awt.*;
//import java.awt.event.*;
//import java.io.FileOutputStream;
//import java.sql.*;
//import java.sql.Connection;
//import java.sql.PreparedStatement;
//import java.sql.ResultSet;
//import java.sql.Statement;
//import java.awt.BorderLayout;


//import javax.swing.JButton;
//import javax.swing.JPanel;
//import java.text.SimpleDateFormat;

//public class ListarVentas extends JFrame {  //1- inicio clase

    //2- atributos- variables de la clase
  //  private JTable tablaVentas;
    //private DefaultTableModel modeloTabla;
    //
    //private JDateChooser fechaInicio;
    //private JDateChooser fechaFin;
    //private JButton btnFiltrar;
    //private JButton btnExportarPDF;


    //3- constructor- se ejecuta cuando se abre la ventana

    //public ListarVentas() {   //inicio constructor  2.1
      //  setTitle("Listado de ventas");
       // setSize(700, 400);
       // setLocationRelativeTo(null);
       // setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
       // setLayout(new BorderLayout());

        //estilo general
        //getContentPane().setBackground(new Color(240, 248, 245));//FONDO PASTEL
        //UIManager.put("Button.background", new Color(204, 229, 255)); //azul pastel para botones
        //UIManager.put("Button.foreground", Color.DARK_GRAY);
        //UIManager.put("Panel background", new Color(204, 229, 255));
        //UIManager.put("Label.foreground", new Color(60, 60, 60)); //gris
        //UIManager.put("Table.background", new Color(255, 255, 255));
        //UIManager.put("Table.selectionBaackground", new Color(255, 204, 229));
        //UIManager.put("Table.selectionForeground", Color.BLACK);

        //crear modelo
        //modeloTabla = new DefaultTableModel();
        //modeloTabla.addColumn("id");
       // modeloTabla.addColumn("cliente");
        //modeloTabla.addColumn("producto");
        //modeloTabla.addColumn("cantidad");
        //modeloTabla.addColumn("total");
        //modeloTabla.addColumn("fecha");

        //tablaVentas = new JTable(modeloTabla);
        //add(new JScrollPane(tablaVentas), BorderLayout.CENTER);

        //PANEL PARA FILTROS
        //JPanel panelFiltros = new JPanel();
        //panelFiltros.setLayout(new FlowLayout());
        //fechaInicio = new JDateChooser();
        //fechaFin = new JDateChooser();
        //btnFiltrar = new JButton("FILTRAR POR FECHA");

        //panel filtros
        //JPanel panelFiltros = new JPanel();
        //panelFiltros.add(new JLabel("DESDE: "));
        //fechaInicio = new JDateChooser();
        //panelFiltros.add(fechaInicio);

        //panelFiltros.add(new JLabel("HASTA"));
        //fechaFin = new JDateChooser();
        //panelFiltros.add(fechaFin);

        //btnFiltrar = new JButton("FILTRAR POR FECHA");
        //panelFiltros.add(btnFiltrar);


        //agregar el panel arriba
        //add(panelFiltros, BorderLayout.NORTH);

        //EVENTO BOTON
        //btnFiltrar.addActionListener(e -> filtrarPorFechas());
        //btnFiltrar = new JButton("Filtrar por fecha");
        //btnExportarPDF = new JButton("Exportar PDF");

        //Color colorBoton = new Color(204, 229, 255);
        //Color colorTexto = new Color(50, 50, 50);
        //java.awt.Font fuenteBoton = new java.awt.Font("Segoe UI", java.awt.Font.BOLD, 13);


        //for (JButton boton : new JButton[]{btnFiltrar, btnExportarPDF}) {
          //  boton.setBackground(colorBoton);
           // boton.setForeground(colorTexto);
           // boton.setFont(fuenteBoton);
            //boton.setFocusPainted(false);
            //boton.setBorder(BorderFactory.createEmptyBorder(8, 15, 8, 15));
            //boton.setCursor(new Cursor(Cursor.HAND_CURSOR));

//            boton.addActionListener(e-> exportarVentasPDF());

  //          JPanel panelBoton = new JPanel();
    //        panelBoton.setBackground(new Color(240,248,245));
      //      panelBoton.add(btnExportarPDF);
        //    add(panelBoton, BorderLayout.SOUTH);
        //}

    //}
    //fin cosntructor


    //crear componentes de fecha
    //fechaInicio = new JDateChooser();
    //fechaFin = new JDateChooser();

    //crear boton filtrar
    //btnFiltrar = new JButton("filtrar");

    //btnFiltrar = new JButton("Filtrar por Fecha");
    //btnFiltrar.addActionListener(e -> filtrarPorFechas());
    //panelBotones.add(btnFiltrar);

    //crear un panel
    //   JPanel panelBotones = new JPanel();
    // panelBotones.add(new JLabel("DESDE: "));
    //panelBotones.add(fechaInicio);
    //panelBotones.add(new JLabel("HASTA: "));
    //panelBotones.add(fechaFin);
    //panelBotones.add(btnFiltrar);

    //add(panelBotones.BorderLayout.NORTH);

    //ACA PODRIAS
    //tablaVentas = new JTable();
    //add(new JScrollPane(tablaVentas), BorderLayout.CENTER);


    //private void filtrarPorFechas() {
      //  if (fechaInicio.getDate() == null || fechaFin.getDate() == null) {
        //    JOptionPane.showMessageDialog(this, "seleccione ambas fechas para filtrar. ");
          //  return;
        //}

        //SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        //String desde = sdf.format(fechaInicio.getDate());
        //String hasta = sdf.format(fechaFin.getDate());

        //modeloTabla.setRowCount(0);//limpia la tabla

        //try (Connection conn = TestConnexion.getConnection()) {
          //  String sql = "SELECT v.id, c.nombre AS cliente, p.nombre AS producto, v.cantidad, v.total, v.fecha "
            //        + "FROM ventas v "
              //      + "JOIN clientes c ON v.id_cliente = c.id "
                //    + "JOIN productos p ON v.id_producto = p.id "
                  //  + "WHERE DATE(v.fecha) BETWEEN ? AND ?";

           // PreparedStatement ps = conn.prepareStatement(sql);
           // ps.setString(1, desde);
           // ps.setString(2, hasta);
           // ResultSet rs = ps.executeQuery();

            //EJEPLO
            //while (rs.next()) {
              //  modeloTabla.addRow(new Object[]{
                //        //System.out.println(
                  //      rs.getInt("id"),
                    //    rs.getString("CLIENTE"),
                      //  rs.getString("producto"),
                        //rs.getInt("cantidad"),
                        //rs.getDouble("total"),
                        //rs.getDate("FECHA")
                //});
            //}

            // acá actualizás la tabla con los resultados
        //} catch (Exception e) {
          //  JOptionPane.showMessageDialog(this, "Error al filtrar: " + e.getMessage());
       // }


        //MODELO DE LA TABLA
        // modeloTabla = new DefaultTableModel();
        //modeloTabla.addColumn("ID");
        //modeloTabla.addColumn("Cliente");
        //modeloTabla.addColumn("Producto");
        //modeloTabla.addColumn("Cantidad");
        //modeloTabla.addColumn("Total");
        //modeloTabla.addColumn("Fecha");

        //tablaVentas = new JTable(modeloTabla);
        //add(new JScrollPane(tablaVentas), BorderLayout.CENTER);


        //JButton btnExportarPDF = new JButton("Exportar a PDF");
        //btnExportarPDF.addActionListener(e -> exportarVentasPDF());
        //add(btnExportarPDF, BorderLayout.SOUTH);

        //cargarVentas();


    //}

    //private void cargarVentas() {
      //  try (Connection conn = TestConnexion.getConnection();
        //     Statement st = conn.createStatement();
          //   ResultSet rs = st.executeQuery(
            //         "SELECT v.id, c.nombre AS Cliente, p.nombre AS producto, v.cantidad, v.total,v.fecha " +
              //               "FROM ventas v " +
                //             "JOIN clientes c ON v.id_cliente = c.id " +
                  //           "JOIN productos p ON v.id_producto = p.id ")) {
//
   //          while (rs.next()) {
     //           Object[] fila = {
       //                 rs.getInt("ID"),
         //               rs.getString("cliente"),
           //             rs.getString("Producto"),
             //           rs.getInt("Cantidad"),
               //         rs.getDouble("Total"),
                 //       rs.getTimestamp("Fecha")
                //};
                //modeloTabla.addRow(fila);
            //}

        //} catch (Exception e) {
          //  JOptionPane.showMessageDialog(this, "Error al cargar ventas: " + e.getMessage());
        //}
   // }

    //private void exportarVentasPDF() {
      //  Document document = new Document();
       // try {
            //crear documento
            //com.itextpdf.text.Document document = new com.itextpdf.text.Document();
            //com.itextpdf.text.pdf.PdfWriter.getInstance(document, new java.io.FileOutputStream("Reporte_Ventas.pdf"));

         //   PdfWriter.getInstance(document, new FileOutputStream("Reporte_Ventas.pdf"));
           // document.open();

            //logo
            //com.itextpdf.text.Image logo = null;

            //logo centrado
            //try {
              //  Image logo = Image.getInstance("Imagenes/logo_tdb.png");
                //logo.scaleToFit(100, 100);
                //logo.setAlignment(Element.ALIGN_CENTER);
                //document.add(logo);

            //} catch (Exception ex) {
              //  System.out.println("Logo no encontrado, continuando sin imagen...");//ex.printStackTrace();
           // }
           // document.add(new Paragraph(" "));

            //com.itextpdf.text.pdf.BaseFont bf = com.itextpdf.text.pdf.BaseFont.createFont(
            //          com.itextpdf.text.pdf.BaseFont.HELVETICA,
            //        com.itextpdf.text.pdf.BaseFont.WINANSI,
            //      com.itextpdf.text.pdf.BaseFont.NOT_EMBEDDED
            //);

            //com.itextpdf.text.Font tituloFont = new com.itextpdf.text.Font(
            //      bf, 16, com.itextpdf.text.Font.BOLD, new com.itextpdf.text.BaseColor(0, 102, 204)
            //);

            //com.itextpdf.text.Font textoFont = new com.itextpdf.text.Font(
            //      bf, 11, com.itextpdf.text.Font.NORMAL, com.itextpdf.text.BaseColor.BLACK
            // );

            //com.itextpdf.text.Paragraph titulo = new com.itextpdf.text.Paragraph("REPORTE DE VENTAS", tituloFont);
            //titulo.setAlignment(com.itextpdf.text.Element.ALIGN_CENTER);
            //document.add(titulo);


            //Image logo = Image.getInstance("imagenes/logo_tdb.png");
            //logo.scaleToFit(100,100);
            //logo.setAlignment(Element.ALIGN_CENTER);
            //document.add(logo);

            //Paragraph titulo = new Paragraph("Reporte de ventas",
            //       new Font(Font.FontFamily.HELVETICA,18, java.awt.Font.BOLD, BaseColor.DARK_GRAY));
            //titulo.setAlignment(Element.ALIGN_CENTER);
            //titulo.setSpacingAfter(20);
            //document.add(titulo);
            //}catch (Exception e){
            //  System.out.println("logo no encontrado, continuandi sin imagen...");
            //}

            //ENCABEZADO CON LOGO Y TITULO
            //com.itextpdf.text.Image logo = null;
            //try {
            //ruta de tu logo(imagen o url)
            //  logo = com.itextpdf.text.Image.getInstance("ruta/logo.png");//cambia a tu ruta
            // logo.scaleToFit(80,80);
            // logo.setAlignment(Element.ALIGN_LEFT);
            // document.add(logo);
            //}catch (Exception ex){
            //  System.out.println("Logo no encontrado, continuando sin imagen...");
            //}

            //-----------------titulo
           // com.itextpdf.text.Font tituloFont = new com.itextpdf.text.Font(
             //       com.itextpdf.text.Font.FontFamily.HELVETICA, 18,
               //     com.itextpdf.text.Font.BOLD, new BaseColor(80, 150, 255));
            //Paragraph titulo = new Paragraph("Reporte de ventas", tituloFont);
            //titulo.setAlignment(Element.ALIGN_CENTER);
            //titulo.setSpacingAfter(15);
            //document.add(titulo);

            //document.add(new Paragraph(" ")); //espacio

            //--------------fecha actual
            //com.itextpdf.text.Font fechaFont = new com.itextpdf.text.Font(
              //      com.itextpdf.text.Font.FontFamily.HELVETICA, 11,
                //    com.itextpdf.text.Font.ITALIC, BaseColor.GRAY);
            //"dd/MM/yyyy HH: mm:s.s");
           // SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH: mm:s.s");
            //Paragraph("Generado el: " + sdf.format(new java.util.Date()),
            //Paragraph fecha = new Paragraph("Generado el: " + sdf.format(new java.util.Date()), fechaFont);
            //  new Font(Font.FontFamily.HELVETICA, 11, Font.ITALIC, BaseColor.DARK_GRAY));
            //fecha.setAlignment(Element.ALIGN_CENTER);
            //fecha.setSpacingAfter(20);
            //document.add(fecha);

            //document.add(new com.itextpdf.text.Paragraph("Reporte de ventas"));
            //document.add(new com.itextpdf.text.Paragraph(" "));

            //------------TABLA DE DATOS

            //com.itextpdf.text.pdf.
            //PdfPTable table = new PdfPTable(6);
            //table.setWidthPercentage(100);
            //table.setSpacingAfter(10f);
            //table.setSpacingAfter(10f);

            //COLORES
            //BaseColor celeste = new BaseColor(173, 216, 230);
            //BaseColor verde = new BaseColor(204, 255, 204);
            //BaseColor rosa = new BaseColor(255, 204, 229);
            //BaseColor amarillo = new BaseColor(255, 255, 204);

            //com.itextpdf.text.Font headersFont = new com.itextpdf.text.Font(
              //      com.itextpdf.text.Font.FontFamily.HELVETICA, 12,
                //    com.itextpdf.text.Font.BOLD, BaseColor.DARK_GRAY
            //);

            //fuente
            //Font headerFont = new Font(Font.FontFamily.HELVETICA, 12, Font.BOLD, BaseColor.DARK_GRAY);

            //ENCABEZADO
            //String[] headers = {"ID", "CLIENTE", "PRODUCTO", "CANTIDAD", "TOTAL", "FECHA"};
            //BaseColor[] colores = {celeste, verde, rosa, amarillo, celeste, verde};

            //for (int i = 0; i < headers.length; i++) {
              //  PdfPCell cell = new PdfPCell(new Phrase(headers[i], headersFont));
                //cell.setBackgroundColor(colores[i % colores.length]);
                //cell.setHorizontalAlignment(Element.ALIGN_CENTER);
                //cell.setPadding(8);
                //table.addCell(cell);
            //}

            //FUENTE-----------
            //Font headerFont = new Font(Font.FontFamily.HELVETICA, 12, Font.BOLD, BaseColor.WHITE);
            //DefaultTableModel modelo = (DefaultTableModel) tablaVentas.getModel();

            //table.addCell("ID");
            //table.addCell("Cliente");
            //table.addCell("Producto");
            //table.addCell("Cantidad");
            //table.addCell("Total");
            //table.addCell("Fecha");

            //------encabezado con color.....FUENTE

            //com.itextpdf.text.Font tituloFont = new com.itextpdf.text.Font(null,12,
            //      com.itextpdf.text.Font.BOLD, new com.itextpdf.text.BaseColor(0,102,204));
            //com.itextpdf.text.pdf.PdfPCell headerCell;

            //String[] headers = {"id","cliente", "producto","cantidad", "total", "fecha"};
            //BaseColor[] colores = {celeste, verde, amarillo};
            //Font headerFont = new Font(Font.FontFamily.HELVETICA, 12, Font.BOLD, BaseColor.WHITE);

            //com.itextpdf.text.Font cellFont = new com.itextpdf.text.Font(
              //      com.itextpdf.text.Font.FontFamily.HELVETICA, 11);
            //filas de la tabla
            //DefaultTableModel modelo = (DefaultTableModel) tablaVentas.getModel();
            //for (int i = 0; i < modelo.getRowCount(); i++) {
              //  for (int j = 0; j < modelo.getColumnCount(); j++) {
                //    Object valor = modelo.getValueAt(i, j);
                  //  PdfPCell cell = new PdfPCell(new Phrase(valor != null ? valor.toString() : "", cellFont));
                    //cell.setBackgroundColor(colores[i % colores.length]);//AZUL
                    //cell.setHorizontalAlignment(Element.ALIGN_CENTER);
                    //cell.setPadding(6);
                    //table.addCell(cell);
                //}
            //}

            //}

            //tomamos el modelo desde la tabla...cuerpo de tablas
            //DefaultTableModel modelo = (DefaultTableModel) tablaVentas.getModel();
            //javax.swing.table.DefaultTableModel modelo = (javax.swing.table.DefaultTableModel) tablaVentas.getModel();
            //com.itextpdf.text.Font cellFont = new com.itextpdf.text.Font(com.itextpdf.text.Font.FontFamily.HELVETICA, 11);


            //for (int i = 0; i < modelo.getRowCount(); i++) {
            //  for (int j = 0; j < modelo.getColumnCount(); j++) {
            // Object valor = modelo.getValueAt(i,j);
            // com.itextpdf.text.pdf.PdfPCell cell = new  com.itextpdf.text.pdf.PdfPCell(new com.itextpdf.text.Phrase(valor != null? valor.toString() : "", cellFont));
            //cell.setHorizontalAlignment(Element.ALIGN_CENTER);
            //cell.setPadding(6);
            //    table.addCell(modelo.getValueAt(i, j).toString());
            //}
            //}
            //document.add(table);
            //document.close();

            //document.add(new Paragraph(" "));

            //-------------pie pagina
            //document.add(new Paragraph(" "));
           // com.itextpdf.text.Font footerFont = new com.itextpdf.text.Font(
             //       com.itextpdf.text.Font.FontFamily.HELVETICA, 10,
               //     com.itextpdf.text.Font.ITALIC, BaseColor.GRAY);
            //Paragraph footer = new Paragraph
              //      ("Sistema de Inventario - 0 " + java.time.Year.now(), footerFont);
            //new com.itextpdf.text.Font
            //              (null, 10, com.itextpdf.text.Font.ITALIC, com.itextpdf.text.BaseColor.GRAY));
            //footer.setAlignment(Element.ALIGN_CENTER);
            //footer.setSpacingBefore(20);
            //document.add(footer);

            //document.close();
            //javax.swing.JOptionPane.showMessageDialog(this,"PDF de ventas generado corectamente: reporte_ventas.pdf");

            //JOptionPane.showMessageDialog(this, "PDF generada correctamente: ventas.pdf");

        //} catch (Exception e) {
            //javax.swing.JOptionPane.showMessageDialog(this, "Error al generar el PDF: " + e.getMessage());
          //  JOptionPane.showMessageDialog(this, "Error al generar el PDF: " + e.getMessage());
        //}
    //}
//}


