import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;

public class ListarClientes  extends JFrame {
    private  JTable tablaClientes;
    private DefaultTableModel modelo;

    public ListarClientes(){
        setTitle("Listado de clientes");
        setSize(700,400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        modelo = new DefaultTableModel(new  String[]{"ID", "Nombre","Telefono","Email","Direccion"},0);
        tablaClientes = new JTable(modelo);

        add(new JScrollPane(tablaClientes), BorderLayout.CENTER);
        cargarClientes();
    }
    private void cargarClientes() {
        try (Connection conn = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/ims?useSSL= false&allowPublicKeyRetrieval=true&serverTimezone= UTC",
                "javauser", "12345")) {

            String sql = "SELECT * FROM clientes";
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            modelo.setRowCount(0);//limpia la tabla
            while (rs.next()) {
                Object[] fila = {
                        rs.getInt("ID"),
                        rs.getString("nombre"),
                        rs.getString("telefono"),
                        rs.getString("email"),
                        rs.getString("direccion")
                };
                modelo.addRow(fila);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error al cargar clientes: " + ex.getMessage());
        }
    }
    public static void main(String[] args){
        SwingUtilities.invokeLater(()-> new ListarClientes().setVisible(true));
    }

    }

