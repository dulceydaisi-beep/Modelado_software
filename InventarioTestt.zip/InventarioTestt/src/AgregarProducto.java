import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class AgregarProducto extends JFrame {

    private JTextField txtNombre, txtDescripcion, txtCantidad, txtPrecio;
    private JComboBox<String> comboCategoria;
    private JButton btnGuardar;

    public AgregarProducto() {

        setTitle("Agregar productos");
        setSize(400, 350);
        setLayout(new GridLayout(6, 2, 10, 10));
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // 🎨 COLORES PASTELES
        Color fondo = new Color(240, 248, 255);      // celeste pastel
        Color btnColor = new Color(173, 216, 230);   // azul suave
        Color texto = new Color(60, 60, 60);         // gris

        getContentPane().setBackground(fondo);

        // 🔹 CAMPOS
        txtNombre = new JTextField();
        txtDescripcion = new JTextField();
        txtCantidad = new JTextField();
        txtPrecio = new JTextField();

        // 🔸 CATEGORÍAS
        String[] categorias = {
                "Bebidas", "Golosinas", "Verdulería", "Carnes",
                "Juguetería", "Ferretería", "Librería",
                "Bijouterie", "Fiambres"
        };
        comboCategoria = new JComboBox<>(categorias);

        // ❤️ BOTÓN GUARDAR
        btnGuardar = new JButton("Guardar");
        btnGuardar.setBackground(btnColor);
        btnGuardar.setForeground(texto);
        btnGuardar.setFont(new Font("Segoe UI", Font.BOLD, 14));

        btnGuardar.addActionListener(this::guardarProducto);

        // 🧱 ARMAR FORMULARIO (ORDEN PERFECTO)
        add(new JLabel("Nombre:"));
        add(txtNombre);

        add(new JLabel("Descripción:"));
        add(txtDescripcion);

        add(new JLabel("Cantidad:"));
        add(txtCantidad);

        add(new JLabel("Precio:"));
        add(txtPrecio);

        add(new JLabel("Categoría:"));
        add(comboCategoria);

        add(new JLabel("")); // espacio vacío
        add(btnGuardar);
    }

    // 💾 GUARDAR PRODUCTO
    private void guardarProducto(ActionEvent e) {

        // Validaciones rápidas
        if (txtNombre.getText().isEmpty() || txtCantidad.getText().isEmpty() || txtPrecio.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Por favor complete todos los campos.");
            return;
        }

        try {
            Connection conn = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/ims?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC",
                    "javauser", "12345"
            );

            String sql = "INSERT INTO productos (nombre, descripcion, cantidad, precio, categoria) VALUES (?, ?, ?, ?, ?)";

            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, txtNombre.getText());
            ps.setString(2, txtDescripcion.getText());
            ps.setInt(3, Integer.parseInt(txtCantidad.getText()));
            ps.setDouble(4, Double.parseDouble(txtPrecio.getText()));
            ps.setString(5, comboCategoria.getSelectedItem().toString());

            ps.executeUpdate();

            JOptionPane.showMessageDialog(this, "Producto guardado correctamente 🎉");

            txtNombre.setText("");
            txtDescripcion.setText("");
            txtCantidad.setText("");
            txtPrecio.setText("");
            comboCategoria.setSelectedIndex(0);

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error al guardar: " + ex.getMessage());
        }
    }

    public static void main(String[] args) {
        new AgregarProducto().setVisible(true);
    }
}
