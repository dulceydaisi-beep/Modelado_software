public class Productos {
    private  int id;
    private String nombre;
    private String descrpcion;
    private int cantidad;
    private  double precio;

    public Productos(int id, String nombre, String descrpcion, int cantidad, double precio){
        this.id = id;
        this.nombre = nombre;
        this.descrpcion = descrpcion;
        this.cantidad = cantidad;
        this.precio = precio;
    }

    @Override
    public String toString() {
        return id + " || " + nombre + " || " + descrpcion + " | Stock: " + cantidad + " |Precio: $" + precio;
    }
}
