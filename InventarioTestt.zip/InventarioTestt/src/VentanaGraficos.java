import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.data.category.DefaultCategoryDataset;

import javax.swing.*;
import java.awt.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class VentanaGraficos extends JFrame {

    public VentanaGraficos() {
        setTitle("Estadísticas Gráficas - Sistema de Inventario");
        setSize(850, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // Fondo degradado
        JPanel panelFondo = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                GradientPaint gp = new GradientPaint(
                        0, 0, new Color(224, 247, 250),
                        0, getHeight(), new Color(200, 230, 255)
                );
                g2d.setPaint(gp);
                g2d.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        panelFondo.setLayout(new BorderLayout());
        add(panelFondo);

        // Crear gráfico
        ChartPanel chartPanel = new ChartPanel(generarGraficoBarras());
        chartPanel.setOpaque(false);
        panelFondo.add(chartPanel, BorderLayout.CENTER);
    }

    private JFreeChart generarGraficoBarras() {

        DefaultCategoryDataset dataset = new DefaultCategoryDataset();

        try (Connection conn = TestConnexion.getConnection()) {
            String sql = "SELECT fecha, SUM(total) as total_dia FROM ventas GROUP BY fecha ORDER BY fecha DESC LIMIT 7";
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                dataset.addValue(
                        rs.getDouble("total_dia"),
                        "Ventas",
                        rs.getString("fecha")
                );
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        JFreeChart chart = ChartFactory.createBarChart(
                "Ventas de los últimos días",
                "Fecha",
                "Total ($)",
                dataset
        );

        return chart;
    }
}


