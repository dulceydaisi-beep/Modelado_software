import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.sql.*;

public class Login extends JFrame {

    private JTextField txtUsuario;
    private JPasswordField txtPassword;
    private JButton btnLogin;

    public Login() {
        setTitle("Inicio de sesión - Sistema de Inventario");
        setSize(800, 500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(true);
        setLayout(new BorderLayout());

        // PANEL DE FONDO CON DEGRADADO MODERNO AZUL
        JPanel panelFondo = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;

                GradientPaint gp = new GradientPaint(
                        0, 0, new Color(0, 102, 204),     // Azul intenso
                        0, getHeight(), new Color(173, 216, 230) // Celeste
                );
                g2d.setPaint(gp);
                g2d.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        panelFondo.setLayout(new BorderLayout());
        setContentPane(panelFondo);

        // PANEL SUPERIOR (LOGO + TÍTULO)
        JPanel panelSuperior = new JPanel(new BorderLayout());
        panelSuperior.setOpaque(false);
        panelSuperior.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JLabel lblLogo = new JLabel();
        ImageIcon icon = new ImageIcon("src/imagenes/logo_tdb.png");
        Image img = icon.getImage().getScaledInstance(180, 180, Image.SCALE_SMOOTH);
        lblLogo.setIcon(new ImageIcon(img));
        lblLogo.setHorizontalAlignment(SwingConstants.CENTER);

        JLabel lblTitulo = new JLabel("Sistema de Inventario", SwingConstants.CENTER);
        lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 34));
        lblTitulo.setForeground(Color.WHITE);

        panelSuperior.add(lblLogo, BorderLayout.NORTH);
        panelSuperior.add(lblTitulo, BorderLayout.CENTER);

        // PANEL CENTRAL (FORMULARIO)
        JPanel panelCentral = new JPanel(new GridBagLayout());
        panelCentral.setOpaque(false); // transparente para ver el degradado
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);

        JLabel lblUsuario = new JLabel("Usuario:");
        lblUsuario.setFont(new Font("Segoe UI", Font.PLAIN, 22));
        lblUsuario.setForeground(Color.WHITE);

        JLabel lblPassword = new JLabel("Contraseña:");
        lblPassword.setFont(new Font("Segoe UI", Font.PLAIN, 22));
        lblPassword.setForeground(Color.WHITE);

        txtUsuario = new JTextField(15);
        txtUsuario.setPreferredSize(new Dimension(250, 35));
        txtUsuario.setText("Daisi"); // usuario por defecto

        txtPassword = new JPasswordField(15);
        txtPassword.setPreferredSize(new Dimension(250, 35));

        gbc.gridx = 0; gbc.gridy = 0;
        panelCentral.add(lblUsuario, gbc);

        gbc.gridx = 1;
        panelCentral.add(txtUsuario, gbc);

        gbc.gridx = 0; gbc.gridy = 1;
        panelCentral.add(lblPassword, gbc);

        gbc.gridx = 1;
        panelCentral.add(txtPassword, gbc);

        // PANEL INFERIOR (BOTÓN)
        JPanel panelInferior = new JPanel();
        panelInferior.setOpaque(false);

        btnLogin = new JButton("INGRESAR");
        btnLogin.setPreferredSize(new Dimension(200, 45));
        btnLogin.setFont(new Font("Segoe UI", Font.BOLD, 18));
        btnLogin.setFocusPainted(false);
        btnLogin.setBackground(new Color(255, 255, 255));
        btnLogin.setForeground(new Color(0, 102, 204));

        panelInferior.add(btnLogin);

        btnLogin.addActionListener((ActionEvent e) -> autenticar());

        // AGREGAR TODO
        add(panelSuperior, BorderLayout.NORTH);
        add(panelCentral, BorderLayout.CENTER);
        add(panelInferior, BorderLayout.SOUTH);
    }

    private void autenticar() {
        String usuario = txtUsuario.getText().trim();
        String password = new String(txtPassword.getPassword()).trim();

        if (usuario.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Complete todos los campos.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try (Connection conn = TestConnexion.getConnection()) {

            String sql = "SELECT * FROM login WHERE username = ? AND password = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, usuario);
            ps.setString(2, password);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                JOptionPane.showMessageDialog(this, "Bienvenida " + usuario + "!");
                dispose();
                new MainMenu(usuario).setVisible(true);
            } else {
                JOptionPane.showMessageDialog(this, "Usuario o contraseña incorrecta.", "Error", JOptionPane.ERROR_MESSAGE);
            }

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error en conexión: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Login().setVisible(true));
    }
}


//import javax.accessibility.AccessibleContext;
//import javax.swing.*;
//import java.awt.*;
//import java.awt.event.ActionEvent;
//import java.awt.event.ActionListener;
//import java.sql.*;

//public class Login extends JFrame {

   // private JTextField txtUsuario;
   // private JPasswordField txtPassword;
   // private JButton btnLogin;
 //   private JButton btnIngresar, btnCancelar;

//    public Login() {
        //setTitle("Inicio de sesión - Sistema de Inventario");
        //setSize(800, 500);
        //setLocationRelativeTo(null);
        //setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      //  setResizable(true);
    //    setLayout(new BorderLayout());

        //txtUsuario = new JTextField(15);
        //txtPassword = new JPasswordField(15);

        //estilo visual
        // Color fondo = new Color(245, 247, 250);
        //Color colorBoton = new Color(41, 128, 185);
        //Color textBoton = Color.WHITE;

        //panel principal
  //      JPanel panelSuperior = new JPanel(new BorderLayout());
        // panel.setBorder(BorderFactory.createEmptyBorder(30, 30, 30, 30));
//        panelSuperior.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        //panelSuperior.setBackground(Color.WHITE);

        //GridBagConstraints gbc = new GridBagConstraints();
        //gbc.fill = GridBagConstraints.HORIZONTAL;
        //add(panel);

        //Fondo degradado
        //JPanel panel = new JPanel() {
        //  @Override
        //protected void paintComponent(Graphics g) {
        //  super.paintComponent(g);
        //Graphics2D g2d = (Graphics2D) g;
        //GradientPaint gp = new GradientPaint(
        //      0, 0, new Color(255, 220, 240),
        //    0, getHeight(), new Color(220, 230, 255));
        //g2d.setPaint(gp);
        //g2d.fillRect(0, 0, getWidth(), getHeight());
        //    }
        //};
        //panel.setLayout(null);
        //add(panel);

        //GridBagConstraints gbc = new GridBagConstraints();
        //gbc.insets = new Insets(5, 5, 5, 5);
        //gbc.fill = GridBagConstraints.HORIZONTAL;
        //gbc.gridx = 0;
        //gbc.gridwidth =2;
        //add(panel);

        //PANEL SUPERIOR
        //JPanel panelSuperior = new JPanel(new BorderLayout());
        //panelSuperior.setBackground(new Color(245,247,250));

        // Logo
    //    JLabel lblLogo = new JLabel();
      //  ImageIcon icon = new ImageIcon("src/imagenes/logo_tdb.png");
  //      Image img = icon.getImage().getScaledInstance(120, 120, Image.SCALE_SMOOTH);
//        lblLogo.setIcon(new ImageIcon(img));

        //lblLogo.setHorizontalAlignment(SwingConstants.CENTER);
        //lblLogo.setBounds(145,20,100,100);
        //try {
        //  ImageIcon icon = new ImageIcon("src/imagenes/logo_tdb.png");
        // Image img = icon.getImage().getScaledInstance(150,150,Image.SCALE_SMOOTH);
        //ImageIcon icono = new ImageIcon(getClass().getResource("/imagenes/logo_tdb.png")); // ruta del logo
        //Image img = icono.getImage().getScaledInstance(100, 100, Image.SCALE_SMOOTH);
        //lblLogo.setIcon(new ImageIcon(img));
        //}catch (Exception e){
        //  System.out.println("No se encontrp la imagen del logo ");
        //}
        //lblLogo.setHorizontalAlignment(SwingConstants.CENTER);
        //gbc.gridx= 0;
        //gbc.gridy = 0;
        //gbc.gridwidth=2;
        //gbc.insets = new Insets(10,5,10,5);
        //panel.add(lblLogo);

        //titulo
        //JLabel lblTitulo = new JLabel("Sistema de Inventario", SwingConstants.CENTER);
        //lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 34));
        //lblTitulo.setForeground(new Color(0, 102, 204));

        //panelSuperior.add(lblLogo, BorderLayout.NORTH);
        //panelSuperior.add(lblTitulo, BorderLayout.CENTER);
        //lblTitulo.setBounds(80,130,250,25);
        //gbc.gridy = 1;
        //panel.add(lblTitulo);

        // usuario

        //gbc.gridwidth = 1;
        //gbc.gridy = 2;
        //gbc.gridx =0;
        //JPanel panelCentral = new JPanel();
        //panelCentral.setLayout(new GridBagLayout());
        //GridBagConstraints gbc = new GridBagConstraints();

        //JLabel lblUsuario = new JLabel("Usuario:");
        //lblUsuario.setFont(new Font("Segoe UI", Font.PLAIN, 20));
        //lblUsuario.setHorizontalAlignment(SwingConstants.RIGHT);
        //lblUsuario.setBounds(70,170,80,25);
        //panel.add(lblUsuario);

        //gbc.gridx = 1;
        //txtUsuario = new JTextField();
        //txtUsuario.setBounds(160,170,170,25);
        //panel.add(txtUsuario);


        //contraseña
        //gbc.gridy = 3;
        //gbc.gridx= 0;
        //JLabel lblPassword = new JLabel("Contraseña: ");
        //lblPassword.setFont(new Font("Segor UI", Font.PLAIN, 20));

        //JTextField txtUsuario = new JTextField(15);
        //txtUsuario.setPreferredSize(new Dimension(250, 35));

        //JPasswordField txtPassword = new JPasswordField(15);
        //txtPassword.setPreferredSize(new Dimension(250, 35));

        //gbc.insets = new Insets(10, 10, 10, 10);

      //  gbc.gridx = 0;
    //    gbc.gridy = 0;
  //      panelCentral.add(lblUsuario, gbc);

//        gbc.gridx = 1;
        //panelCentral.add(txtUsuario, gbc);

        //gbc.gridx = 0;
        //gbc.gridy = 1;
        //panelCentral.add(lblPassword, gbc);

        //JPanel panelInferior = new JPanel();
      //  JButton btnLogin = new JButton("INGRESAR");
    //    btnLogin.setPreferredSize(new Dimension(200, 45));
  //      btnLogin.setFont(new Font("Segoe UI", Font.BOLD, 18));
//        panelInferior.add(btnLogin);

       // add(panelSuperior, BorderLayout.NORTH);
       // add(panelCentral, BorderLayout.CENTER);
      //  add(panelInferior, BorderLayout.SOUTH);
    //}

        //lblPassword.setBounds(70,210,170,25);
        //lblPassword.setHorizontalAlignment(SwingConstants.RIGHT);
        //panel.add(lblPassword);

        //gbc.gridx = 1;
        //txtPassword = new JPasswordField();
        //txtPassword.setBounds(160,220,170,25);
        //JPasswordField txtPassword = new JPasswordField(15);
        //panel.add(txtPassword);

        //boton
        //gbc.gridy = 4;
        //gbc.gridx= 0;
        //gbc.gridwidth= 2;
        //JButton btnLogin = new JButton("Ingresar");
        //btnLogin.setBackground(new Color(0,102,204));
        //btnLogin.setForeground(Color.WHITE);
        //btnLogin.setFont(new Font("segoe UI", Font.BOLD,14));
        //btnLogin.setBounds(120,260,160,35);
        //panel.add(btnLogin);

        //accion
        //btnLogin.addActionListener(e->{
            //String usuario = txtUsuario.getText().trim();
          //  String password = new String(txtPassword.getPassword()).trim();

        //});

        //lblTitulo.setBorder(BorderFactory.createEmptyBorder(10,0,20,0));

        //agregamos panel
        //panelSuperior.add(lblLogo, BorderLayout.NORTH);
        //panelSuperior.add(lblTitulo, BorderLayout.CENTER);
        //add(panelSuperior, BorderLayout.NORTH);

        // --- UBICACIÓN LOGO ---
        //gbc.gridx = 0;
        //gbc.gridy = 0;
        //gbc.gridwidth = 2;
        //panel.add(lblLogo, gbc);

      // --- TÍTULO ---
        //gbc.gridy++;
        //panel.add(lblTitulo, gbc);

        //JLabel lblUsuario = new JLabel("Usuario:");
        //JLabel lblPassword = new JLabel("Contraseña");
        //txtUsuario = new JTextField(15);
        //txtPassword = new JPasswordField(15);
        //btnIngresar = new JButton("Ingresar");

        //btnIngresar.setBackground(new Color(0, 102, 204));
        //btnIngresar.setForeground(Color.WHITE);
        //btnIngresar.setFont(new Font("Segoe UI", Font.BOLD, 14));
        //btnIngresar.setCursor(new Cursor(Cursor.HAND_CURSOR));

        //UBICACION
        //gbc.gridx = 0;
        //gbc.gridy = 0;
        //gbc.gridwidth = 2;
        //panel.add(lblTitulo, gbc);

        //gbc.gridwidth = 1;
        //gbc.gridy++;
        //panel.add(lblUsuario, gbc);
        //gbc.gridy = 1;
        //panel.add(txtUsuario, gbc);

        //gbc.gridx = 0;
        //gbc.gridy++;
        //panel.add(lblPassword, gbc);
        //gbc.gridx = 1;
        //panel.add(txtPassword, gbc);

        //gbc.gridx = 0;
        //gbc.gridy++;
        //gbc.gridwidth = 2;
        //panel.add(btnIngresar, gbc);

        //add(panel);

        //boton
        //btnIngresar.addActionListener((ActionEvent e) -> autenticar());
    //}


        //logo
       // JLabel lblLogo = new JLabel();
        //lblLogo.setHorizontalAlignment(SwingConstants.CENTER);
        //try {
        //ImageIcon logoicon = new ImageIcon("src/imagenes/logo_tdb.png");
        //Image img = logoIcon.getImage().getScaledInstance(80, 80, Image.SCALE_SMOOTH);
        //JLabel lblLogo = new JLabel(new ImageIcon(img));

        // ubicacion
        //gbc.gr
        //} catch (Exception e) {
          //  lblLogo.setText("LOGO");
       // }
        //PANEL FORMULARIO
        //JPanel formPanel = new JPanel(new GridLayout(5, 1, 10, 10));
        //formPanel.setOpaque(false);
        //formPanel.setBorder(BorderFactory.createEmptyBorder(20, 50, 20, 50));

       // JLabel lblTitulo = new JLabel("Iniciar sesión", SwingConstants.CENTER);
        //lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 22));
        //lblTitulo.setForeground(new Color(0, 102, 204));

        //public AccessibleContext getAccessibleContext() {
        //  return super.getAccessibleContext();
        //}
        //}

        //TITULO...componentes
        //JLabel lblUsuario = new JLabel("Usuario:");
        //JLabel lblContraseña = new JLabel("Contraseña:");

        //txtUsuario = new JTextField();
        //txtUsuario.setBorder(BorderFactory.createTitledBorder("Usuario"));
       // txtUsuario.setPreferredSize(new Dimension(250,35));

        //txtPassword = new JPasswordField();
        //txtPassword.setBorder(BorderFactory.createTitledBorder("Contraseña"));
        //txtPassword.setPreferredSize(new Dimension(250,35));

        //btnLogin = new JButton("Ingresar");
        //btnLogin.setPreferredSize(new Dimension(200, 45));
        //btnLogin.setForeground(Color.WHITE);
        //btnLogin.setFont(new Font("Segoe UI", Font.BOLD, 18));
        //btnLogin.setFocusPainted(false);
        //btnLogin.setCursor(new Cursor(Cursor.HAND_CURSOR));

        //EFECTO HOVER
        //btnLogin.addMouseListener(new java.awt.event.MouseAdapter() {
          //  public void mouseEntered(java.awt.event.MouseAdapter evt) {
            //    btnLogin.setBackground(new Color(0, 85, 170));
            //}

            //public void mouseExited(java.awt.event.MouseAdapter evt) {
              //  btnLogin.setBackground(new Color(0, 102, 204));
            //}
        //});
        //evento del boton
        //btnLogin.addActionListener((ActionEvent e) -> autenticar());

        //formPanel.add(lblTitulo);
        //formPanel.add(txtUsuario);
        //formPanel.add(txtPassword);
        //formPanel.add(btnLogin);

        //panel.add(lblLogo, BorderLayout.NORTH);
        //panel.add(formPanel, BorderLayout.CENTER);
    //}


    //   btnIngresar = new JButton("Ingresar");
    // btnCancelar = new JButton("Cancelar");

    //Agreagr componetes
    //panel.add(lblUsuario);
    //panel.add(txtUsuario);
    //panel.add(lblContraseña);
    //panel.add(txtPassword);
    //panel.add(btnIngresar);
    //panel.add(btnCancelar);

    //add(panel,BorderLayout.CENTER);

    //accion del boton ingresar
    //btnIngresar.addActionListener(e-> validarLogin());

    //accion del boton cancelar
    //btnCancelar.addActionListener(e-> System.exit(0));

    //setVisible(true);

    //
//gbc.gridx=0;
    //gbc.gridy=0;
    //gbc.gridwidth= 2;
    //panel.add(lblTitulo,gbc);

    //campos de texto
    //gbc.gridwidth=1;
    //gbc.gridy++;
    //panel.add(new JLabel("Usuario:"),gbc);
    //gbc.gridx=1;
    //txtUsuario = new JTextField(15);
    //panel.add(txtUsuario,gbc);

    //gbc.gridx = 0;
    //gbc.gridy++;
    //panel.add(new JLabel("Contraseña: "), gbc);
    //gbc.gridx = 1;
    //txtPassword = new JPasswordField(15);
    //panel.add(txtPassword,gbc);

    //boton iniciar sesión
    //gbc.gridx = 0;
    //gbc.gridy++;
    //gbc.gridwidth = 2;
    //JButton btnLogin = new JButton("Iniciar sesión");
    //btnLogin.setBackground(colorBoton);
    //btnLogin.setForeground(textBoton);
    //btnLogin.setFont(new Font("Segoe UI", Font.BOLD,14));
    //btnLogin.setFocusPainted(false);
    //btnLogin.setCursor(new Cursor(Cursor.HAND_CURSOR));
    //panel.add(btnLogin,gbc);

    //accion del boton
    //btnLogin.addActionListener((ActionEvent e)-> verificarCredenciales());

    //add(panel);

    //private void autenticar() {
      //  String usuario = txtUsuario.getText().trim();
        //String password = new String(txtPassword.getPassword()).trim();

        //System.out.println("Usuario ingresado; " + usuario);
        //System.out.println("Contrasela ingresada: " + password);

        //VALIDACION BSICA

        //if (usuario.isEmpty() || password.isEmpty()) {
          //  JOptionPane.showMessageDialog(this, "Complete todos los campos. ", "Error", JOptionPane.ERROR_MESSAGE);
        //    return;
            //JOptionPane.showMessageDialog(this, "Bienvenido" + usuario);
            //dispose();
            //new MainMenu(usuario).setVisible(true);
            //} else {
            //  JOptionPane.showMessageDialog(this, "Usuario o contraseña incorrectos", "Error", JOptionPane.ERROR_MESSAGE);
      //  }

    //

    //try(Connection conn = TestConnexion.getConnection()){
        //String sql = "SELECT * FROM login WHERE username = ? AND password = ?";
        //PreparedStatement ps = conn.prepareStatement(sql);

        //ps.setString(1, usuario);
        //ps.setString(2, password);
        //ps.setString(2, new String(txtPassword.getPassword()).trim());

        //ResultSet rs = ps.executeQuery();
        //System.out.println("Intentando conectar con: " + usuario + " / " + password);

        //System.out.println("Usuario: "+ usuario + "Contraseña: " + password);

        //if (rs.next()) {
            //JOptionPane.showMessageDialog(this, "Bienvenido " + usuario + "!");
            //dispose();
          //  new MainMenu(usuario).setVisible(true);

            //new MainMenu(usuario).setVisible(true);
            //    this.dispose(); //cierra la ventana login
        //} else {
        //    JOptionPane.showMessageDialog(this, "Usuario o contraseñas incorrectas", "Error", JOptionPane.ERROR_MESSAGE);
      //  }
    //}catch(SQLException ex) {
    //    JOptionPane.showMessageDialog(this, "Error de conexion: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
  //  }
//});
    //}

    //public static void main(String[] args) {
    //    SwingUtilities.invokeLater(() -> new Login().setVisible(true));
  //  }
//}
    //try (
    //Class.forName("com.mysql.cj.jdbc.Driver");
    //  Connection conn = DriverManager.getConnection(
    //        "jdbc:mysql://localhost:3306/ims?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone= UTC",
    //      "javauser","12345"
    // )){
    //String sql = "SELECT * FROM usuarios WHERE nombre_usuario=? AND contrasena=?";
    //PreparedStatement ps = conn.prepareStatement(sql);
    //ps.setString(1,usuario);
    //ps.setString(2,password);

    //ResultSet rs = ps.executeQuery();


    //conn.close();
    //}catch (SQLException ex){
    //   JOptionPane.showMessageDialog(this,"Error al conectar " + ex.getMessage());



