import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;


public class Main {
    public static void main(String[] args) {
        //datos de conexion
        String url = "jdbc:mysql://localhost:3306/ims";
        String user = "root";     //tu usuario de MySQL
        String password = "";  //pone la contraseña que usas en worbench

        try {
            //conestar a la base
            Connection con = DriverManager.getConnection(url, user, password);
            System.out.println("  Conexion existosa a la base de datos!");

            //crear un statement para ejecutar SQL
            Statement stmt = con.createStatement();

            //consultar los usarios de la tabala login
            ResultSet rs = stmt.executeQuery("SELECT * FROM productos");

            System.out.println("Mercaderia en stock: ");
            System.out.println("----------------------------------------");
            while (rs.next()){
                Productos p = new Productos(
                rs.getInt("id"),
                rs.getString("nombre"),
                rs.getString("descripcion"),
                rs.getInt("cantidad"),
                rs.getDouble("precio")
                );
                System.out.println(p);

            }

            //cerrar conexion
            con.close();
        }catch (Exception e){
            System.out.println(" x Error al conectar: " + e.getMessage());
            e.printStackTrace();
        }
    }
}